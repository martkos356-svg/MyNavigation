#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/Test.kt" <<'KOTLIN'
import ru.mynavigation.app.RouteProgressMath

fun main() {
    check(RouteProgressMath.estimateRemainingMinutes(100.0, 80.0, 25.0) == 20)
    check(RouteProgressMath.estimateRemainingMinutes(100.0, 80.0, 150.0) == 80)
    check(RouteProgressMath.estimateRemainingMinutes(0.0, 10.0, 2.0) == null)
    check(RouteProgressMath.estimateRemainingMinutes(10.0, 20.0, -1.0) == null)
    println("Route progress math test: OK")
}
KOTLIN
kotlinc "$ROOT/app/src/main/java/ru/mynavigation/app/RouteProgressMath.kt" "$TMP/Test.kt" -include-runtime -d "$TMP/test.jar"
java -jar "$TMP/test.jar"
