#!/usr/bin/env bash
# Build an offline address/place catalogue from the Siberian Federal District OSM extract.
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK_DIR="${WORK_DIR:-$ROOT_DIR/work}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/output}"
PBF_URL="${PBF_URL:-https://download.geofabrik.de/russia/siberian-fed-district-latest.osm.pbf}"
PBF_FILE="${PBF_FILE:-$WORK_DIR/siberian-fed-district-latest.osm.pbf}"
BBOX="${BBOX:-83.5,51.5,90.5,57.5}"
for cmd in curl osmium python3; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "ERROR: missing required command: $cmd" >&2; exit 2; }
done
mkdir -p "$WORK_DIR" "$OUTPUT_DIR"
trap 'rm -f "$PBF_FILE.part" "$WORK_DIR/kuzbass-selected.osm.pbf.part" "$WORK_DIR/kuzbass.geojsonseq.part"' EXIT
if [[ ! -s "$PBF_FILE" ]]; then
  echo "Downloading regional OSM data: $PBF_URL"
  curl --fail --location --proto '=https' --tlsv1.2 --retry 3 --output "$PBF_FILE.part" "$PBF_URL"
  [[ -s "$PBF_FILE.part" ]] || { echo "ERROR: empty PBF download" >&2; exit 3; }
  mv "$PBF_FILE.part" "$PBF_FILE"
fi
osmium fileinfo "$PBF_FILE" >/dev/null
CLIPPED="$WORK_DIR/kuzbass-corridor.osm.pbf"
echo "Clipping OSM data to $BBOX"
osmium extract --overwrite --strategy=smart --bbox="$BBOX" "$PBF_FILE" --output="$CLIPPED"
osmium fileinfo "$CLIPPED" >/dev/null
SELECTED="$WORK_DIR/kuzbass-selected.osm.pbf"
# Address objects, named settlements/POIs and named road classes.
osmium tags-filter --overwrite "$CLIPPED" \
  n/addr:* w/addr:* r/addr:* \
  n/place w/place r/place \
  n/amenity w/amenity n/shop w/shop n/tourism w/tourism \
  n/leisure w/leisure n/highway w/highway \
  --output="$SELECTED"
osmium fileinfo "$SELECTED" >/dev/null
GEOJSON="$WORK_DIR/kuzbass.geojsonseq"
echo "Exporting searchable features"
osmium export --overwrite --output-format=geojsonseq "$SELECTED" --output="$GEOJSON"
OUT="$OUTPUT_DIR/kuzbass_places.sqlite"
python3 "$ROOT_DIR/build_kuzbass_gazetteer.py" "$GEOJSON" "$OUT"
(
  cd "$OUTPUT_DIR"
  sha256sum kuzbass_places.sqlite > kuzbass_places.sqlite.sha256
)
echo ""
echo "SUCCESS: offline gazetteer created"
echo "  Database: $OUT"
echo "  SHA256:   $(cut -d ' ' -f1 "$OUT.sha256")"
echo "Copy the SQLite file to the Android device and import it with the app's offline catalogue button."
echo "OpenStreetMap attribution is required; see README in this directory."
