#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
cat > "$TMP_DIR/sample.geojsonseq" <<'JSON'
{"type":"Feature","properties":{"@id":"node/1","name":"Новокузнецк","place":"city","name:ru":"Новокузнецк"},"geometry":{"type":"Point","coordinates":[87.136,53.755]}}
{"type":"Feature","properties":{"@id":"node/2","addr:street":"проспект Металлургов","addr:housenumber":"1","addr:city":"Новокузнецк"},"geometry":{"type":"Point","coordinates":[87.12,53.76]}}
{"type":"Feature","properties":{"@id":"way/3","name":"Кемерово — Новокузнецк","highway":"primary"},"geometry":{"type":"LineString","coordinates":[[86.0,55.0],[87.0,54.0]]}}
JSON
python3 "$ROOT_DIR/build_kuzbass_gazetteer.py" "$TMP_DIR/sample.geojsonseq" "$TMP_DIR/sample.sqlite" --min-records 1
python3 - "$TMP_DIR/sample.sqlite" <<'PY'
import sqlite3, sys
con = sqlite3.connect(sys.argv[1])
assert con.execute("select count(*) from places").fetchone()[0] == 3
assert con.execute("select count(*) from places where search_text like '%металлургов%' and search_text like '%1%'").fetchone()[0] == 1
assert con.execute("select value from metadata where key='schema_version'").fetchone()[0] == '2'
assert con.execute("select count(*) from place_tokens").fetchone()[0] > 0
rows = con.execute("select p.name from places p where exists (select 1 from place_tokens t where t.place_id=p.id and t.token glob 'металл*') and exists (select 1 from place_tokens t where t.place_id=p.id and t.token glob 'проспект*')").fetchall()
assert rows and rows[0][0] == 'проспект Металлургов, 1'
print('Gazetteer builder fixture test: OK')
PY
