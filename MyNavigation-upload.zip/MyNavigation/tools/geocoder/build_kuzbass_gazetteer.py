#!/usr/bin/env python3
"""Convert an Osmium GeoJSONSeq export into a compact SQLite offline gazetteer."""
import argparse
import json
import math
import os
import sqlite3
import sys
import re
import unicodedata


def coords_from_geometry(geometry):
    if not isinstance(geometry, dict):
        return []
    kind = geometry.get("type")
    coords = geometry.get("coordinates")
    points = []
    def walk(value):
        if isinstance(value, list):
            if len(value) >= 2 and isinstance(value[0], (int, float)) and isinstance(value[1], (int, float)):
                lon, lat = float(value[0]), float(value[1])
                if math.isfinite(lat) and math.isfinite(lon) and -90 <= lat <= 90 and -180 <= lon <= 180:
                    points.append((lon, lat))
            else:
                for child in value:
                    walk(child)
    walk(coords)
    if not points:
        return None
    if kind == "Point":
        return points[0][1], points[0][0]
    # A simple coordinate mean is stable and sufficient for search-result pins.
    return sum(p[1] for p in points) / len(points), sum(p[0] for p in points) / len(points)


def clean(value):
    return " ".join(str(value or "").replace("\x00", " ").split())[:500]


def normalize_search(value):
    value = unicodedata.normalize("NFKD", value).casefold().replace("ё", "е")
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    return " ".join(re.findall(r"[^\W_]+", value, flags=re.UNICODE))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input", help="Osmium GeoJSONSeq file")
    ap.add_argument("output", help="Output SQLite database")
    ap.add_argument("--min-records", type=int, default=100, help="Minimum accepted feature count (default: 100)")
    args = ap.parse_args()
    if not os.path.isfile(args.input) or os.path.getsize(args.input) == 0:
        raise SystemExit("Input GeoJSONSeq is missing or empty")
    if os.path.exists(args.output):
        os.remove(args.output)
    db = sqlite3.connect(args.output)
    try:
        db.executescript("""
          PRAGMA journal_mode=OFF;
          PRAGMA synchronous=OFF;
          PRAGMA temp_store=MEMORY;
          CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
          CREATE TABLE places (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, search_text TEXT NOT NULL,
            lat REAL NOT NULL, lon REAL NOT NULL, kind TEXT NOT NULL
          );
          CREATE INDEX places_name_idx ON places(name);
          CREATE INDEX places_kind_idx ON places(kind);
          CREATE TABLE place_tokens (token TEXT NOT NULL, place_id TEXT NOT NULL,
            FOREIGN KEY(place_id) REFERENCES places(id) ON DELETE CASCADE);
          CREATE UNIQUE INDEX place_tokens_unique_idx ON place_tokens(token, place_id);
          CREATE INDEX place_tokens_token_idx ON place_tokens(token);
        """)
        inserted = 0
        with open(args.input, "r", encoding="utf-8") as source:
            for line_no, line in enumerate(source, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    feature = json.loads(line)
                except json.JSONDecodeError:
                    continue
                tags = feature.get("properties") or {}
                # Osmium export stores OSM tags alongside @id/@type metadata.
                if not isinstance(tags, dict):
                    continue
                address = {k: v for k, v in tags.items() if k.startswith("addr:")}
                name = clean(tags.get("name:ru") or tags.get("name") or tags.get("official_name") or tags.get("short_name"))
                street = clean(address.get("addr:street") or address.get("addr:place"))
                house = clean(address.get("addr:housenumber"))
                locality = clean(address.get("addr:city") or address.get("addr:town") or address.get("addr:village") or tags.get("is_in"))
                if not name:
                    if street and house:
                        name = f"{street}, {house}"
                    elif street:
                        name = street
                    elif house and locality:
                        name = f"{locality}, {house}"
                    else:
                        continue
                position = coords_from_geometry(feature.get("geometry"))
                if position is None:
                    continue
                lat, lon = position
                osm_id = str(tags.get("@id") or f"line:{line_no}")
                kind = clean(tags.get("place") or tags.get("amenity") or tags.get("shop") or tags.get("tourism") or tags.get("highway") or tags.get("building") or "address")
                searchable = [name, street, house, locality]
                for key in ("official_name", "alt_name", "short_name", "name", "name:ru", "ref", "brand", "addr:postcode", "addr:district", "addr:suburb"):
                    searchable.append(clean(tags.get(key)))
                search_text = normalize_search(" ".join(dict.fromkeys(x for x in searchable if x)))
                try:
                    # Remove any previous token rows before replacing a duplicate OSM ID.
                    db.execute("DELETE FROM place_tokens WHERE place_id=?", (osm_id,))
                    db.execute("INSERT OR REPLACE INTO places(id,name,search_text,lat,lon,kind) VALUES(?,?,?,?,?,?)",
                               (osm_id, name, search_text, lat, lon, kind))
                    tokens = set(search_text.split())
                    db.executemany("INSERT OR IGNORE INTO place_tokens(token,place_id) VALUES(?,?)",
                                   ((token, osm_id) for token in tokens if len(token) >= 2))
                    inserted += 1
                except sqlite3.Error as exc:
                    print(f"Skipping feature {osm_id}: {exc}", file=sys.stderr)
                if inserted and inserted % 10000 == 0:
                    db.commit()
                    print(f"Indexed {inserted:,} features", file=sys.stderr)
        db.execute("INSERT INTO metadata(key,value) VALUES('schema_version','2')")
        db.execute("INSERT INTO metadata(key,value) VALUES('source','OpenStreetMap regional extract; see OSM attribution')")
        actual_count = db.execute("SELECT COUNT(*) FROM places").fetchone()[0]
        db.execute("INSERT INTO metadata(key,value) VALUES('record_count',?)", (str(actual_count),))
        db.commit()
        db.execute("ANALYZE")
        db.commit()
        print(f"Created {args.output}: {actual_count:,} searchable features, {os.path.getsize(args.output):,} bytes")
        if actual_count < max(1, args.min_records):
            raise SystemExit(f"Too few records ({actual_count}); expected at least {args.min_records}. Check the OSM extract and tag filters")
    finally:
        db.close()


if __name__ == "__main__":
    main()
