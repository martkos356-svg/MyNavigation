#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

fail() { printf 'BUILD BLOCKED: %s\n' "$1" >&2; exit 2; }
command -v java >/dev/null 2>&1 || fail 'Java is not installed.'
command -v gradle >/dev/null 2>&1 || fail 'Gradle is not installed. Install Gradle 8.11.1 or provide a Gradle wrapper.'
[[ -n "${ANDROID_HOME:-}${ANDROID_SDK_ROOT:-}" ]] || fail 'Android SDK is not configured. Set ANDROID_HOME or ANDROID_SDK_ROOT.'

GRADLE_VERSION="$(gradle --version | awk '/^Gradle / {print $2; exit}')"
[[ "$GRADLE_VERSION" == 8.11.1 ]] || printf 'WARNING: expected Gradle 8.11.1 for AGP 8.10.1; found %s.\n' "${GRADLE_VERSION:-unknown}" >&2

gradle --no-daemon --stacktrace :app:assembleDebug
APK="$ROOT/app/build/outputs/apk/debug/app-debug.apk"
[[ -s "$APK" ]] || fail "Gradle finished but APK was not found at $APK"
printf '\nAPK created: %s\n' "$APK"
