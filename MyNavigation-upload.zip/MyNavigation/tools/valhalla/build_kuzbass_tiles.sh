#!/usr/bin/env bash
# Build an offline Valhalla tile extract for Kuzbass from Geofabrik OSM data.
# Run on Linux/WSL with osmium-tool and Valhalla build utilities installed.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK_DIR="${WORK_DIR:-$ROOT_DIR/work}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/output}"
PBF_URL="${PBF_URL:-https://download.geofabrik.de/russia/siberian-fed-district-latest.osm.pbf}"
PBF_FILE="${PBF_FILE:-$WORK_DIR/siberian-fed-district-latest.osm.pbf}"
# Broad corridor around Kemerovo, Novokuznetsk and connecting roads.
# Format: west,south,east,north (longitude/latitude).
BBOX="${BBOX:-83.5,51.5,90.5,57.5}"

required=(curl osmium jq valhalla_build_config valhalla_build_timezones valhalla_build_admins valhalla_build_tiles valhalla_build_extract sha256sum)
for cmd in "${required[@]}"; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "ERROR: required command not found: $cmd" >&2
    exit 2
  }
done

mkdir -p "$WORK_DIR" "$OUTPUT_DIR"
trap 'rm -f "$PBF_FILE.part" "$WORK_DIR/kuzbass-corridor.osm.pbf.part"' EXIT
mkdir -p "$WORK_DIR/valhalla_tiles"

if [[ ! -s "$PBF_FILE" ]]; then
  echo "Downloading regional OSM PBF: $PBF_URL"
  curl --fail --location --proto '=https' --tlsv1.2 --retry 3 --output "$PBF_FILE.part" "$PBF_URL"
  [[ -s "$PBF_FILE.part" ]] || { echo "ERROR: downloaded PBF is empty" >&2; exit 3; }
  mv "$PBF_FILE.part" "$PBF_FILE"
fi

# Validate input before spending time on the routing build.
osmium fileinfo "$PBF_FILE" >/dev/null

CLIPPED_PBF="$WORK_DIR/kuzbass-corridor.osm.pbf"
echo "Extracting corridor bbox: $BBOX"
osmium extract --overwrite --strategy=smart --bbox="$BBOX" "$PBF_FILE" --output="$CLIPPED_PBF"
osmium fileinfo "$CLIPPED_PBF" >/dev/null

TILE_DIR="$WORK_DIR/valhalla_tiles"
# Prevent stale tiles from an earlier build from leaking into the new extract.
rm -rf "$TILE_DIR"
mkdir -p "$TILE_DIR"
CONFIG="$WORK_DIR/valhalla.json"
EXTRACT="$OUTPUT_DIR/valhalla_kuzbass.tar"

# Keep the larger regional PBF for admin boundaries; build routable tiles from
# the smaller corridor extract. Timezone data is generated independently.
valhalla_build_config \
  --mjolnir-tile-dir "$TILE_DIR" \
  --mjolnir-tile-extract "$EXTRACT" \
  --mjolnir-timezone "$TILE_DIR/timezones.sqlite" \
  --mjolnir-admin "$TILE_DIR/admins.sqlite" > "$CONFIG"

valhalla_build_timezones > "$TILE_DIR/timezones.sqlite"
valhalla_build_admins -c "$CONFIG" "$PBF_FILE"
valhalla_build_tiles -c "$CONFIG" "$CLIPPED_PBF"
valhalla_build_extract -c "$CONFIG" -v

# Verify that the resulting graph can route between both main cities.
"$ROOT_DIR/test_kuzbass_routes.sh" "$CONFIG"

[[ -s "$EXTRACT" ]] || {
  echo "ERROR: Valhalla did not create the configured extract: $EXTRACT" >&2
  exit 4
}

(
  cd "$OUTPUT_DIR"
  sha256sum "$(basename "$EXTRACT")" > "$(basename "$EXTRACT").sha256"
)

cat <<REPORT

SUCCESS: Valhalla extract created
  File:   $EXTRACT
  SHA256: $(cut -d ' ' -f1 "$EXTRACT.sha256")

Copy this TAR to an HTTPS host, then configure the Android installer with
its URL and the SHA-256 above. Test routes near the bbox edges as well as
Kemerovo <-> Novokuznetsk before distributing it.
REPORT
