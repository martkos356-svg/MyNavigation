#!/usr/bin/env bash
# Smoke-test a built Valhalla extract with a real Kemerovo <-> Novokuznetsk route.
set -Eeuo pipefail

CONFIG="${1:-$(dirname "$0")/work/valhalla.json}"
command -v valhalla_service >/dev/null 2>&1 || { echo "ERROR: valhalla_service is required" >&2; exit 2; }
command -v jq >/dev/null 2>&1 || { echo "ERROR: jq is required" >&2; exit 2; }
[[ -s "$CONFIG" ]] || { echo "ERROR: config not found: $CONFIG" >&2; exit 2; }

# City-center coordinates; routing snaps them to the nearest routable road edge.
KEMEROVO='{"lat":55.3547,"lon":86.0873,"type":"break"}'
NOVOKUZNETSK='{"lat":53.7575,"lon":87.1361,"type":"break"}'

run_route() {
  local label="$1" from="$2" to="$3" response
  echo "Testing: $label"
  response="$(valhalla_service "$CONFIG" route "$(jq -cn --argjson a "$from" --argjson b "$to" '{locations:[$a,$b],costing:"auto",directions_options:{units:"kilometers",language:"ru-RU"}}')")"
  if ! jq -e '(.trip.legs | length) > 0 and (.trip.legs[0].summary.length > 0) and (.trip.legs[0].summary.time > 0)' >/dev/null <<<"$response"; then
    echo "ERROR: route response is invalid:" >&2
    jq . <<<"$response" >&2 || printf '%s\n' "$response" >&2
    return 1
  fi
  jq -r '"  Distance: \(.trip.legs[0].summary.length | tostring) km; duration: \((.trip.legs[0].summary.time / 60 | round) | tostring) min"' <<<"$response"
}

run_route 'Kemerovo -> Novokuznetsk' "$KEMEROVO" "$NOVOKUZNETSK"
run_route 'Novokuznetsk -> Kemerovo' "$NOVOKUZNETSK" "$KEMEROVO"
echo 'SUCCESS: both intercity directions routed successfully.'
