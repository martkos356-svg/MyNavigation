package ru.mynavigation.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.util.Locale

/** Small on-device index of destinations the user has previously selected or saved. */
class OfflinePlaceIndex(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("offline_place_index", Context.MODE_PRIVATE)
    private val key = "places_v1"

    @Synchronized
    fun remember(place: Place) {
        if (!place.lat.isFinite() || !place.lon.isFinite() || place.lat !in -90.0..90.0 || place.lon !in -180.0..180.0) return
        val current = readAll().toMutableList()
        current.removeAll { kotlin.math.abs(it.lat - place.lat) < 0.00005 && kotlin.math.abs(it.lon - place.lon) < 0.00005 }
        current.add(0, place.copy(name = place.name.take(240)))
        val json = JSONArray()
        current.take(MAX_ENTRIES).forEach { item ->
            json.put(JSONObject().put("name", item.name).put("lat", item.lat).put("lon", item.lon))
        }
        prefs.edit().putString(key, json.toString()).apply()
    }

    fun search(query: String, limit: Int = 8): List<Place> {
        val needle = normalize(query)
        if (needle.length < 2) return emptyList()
        return readAll().asSequence()
            .filter { normalize(it.name).contains(needle) }
            .distinctBy { "${it.lat},${it.lon}" }
            .take(limit.coerceIn(1, 20))
            .toList()
    }

    @Synchronized
    private fun readAll(): List<Place> = runCatching {
        val raw = prefs.getString(key, null) ?: return emptyList()
        val array = JSONArray(raw)
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val lat = item.optDouble("lat", Double.NaN)
                val lon = item.optDouble("lon", Double.NaN)
                val name = item.optString("name").trim()
                if (name.isNotEmpty() && lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0) {
                    add(Place(name, lat, lon))
                }
            }
        }
    }.getOrDefault(emptyList())

    private fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "")
        .lowercase(Locale.ROOT)
        .replace('ё', 'е')
        .replace("[^\\p{L}\\p{N}]+".toRegex(), " ")
        .trim()

    companion object { private const val MAX_ENTRIES = 300 }
}
