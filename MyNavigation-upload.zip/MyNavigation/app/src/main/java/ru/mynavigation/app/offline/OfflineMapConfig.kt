package ru.mynavigation.app.offline

/**
 * Укажите здесь URL стиля от поставщика карт, который явно разрешает
 * предварительную загрузку/офлайн-кэширование. Не используйте публичный
 * стандартный сервер тайлов tile.openstreetmap.org для массовой загрузки.
 */
object OfflineMapConfig {
    const val STYLE_URL = ""

    data class RegionPreset(
        val id: String,
        val title: String,
        val north: Double,
        val east: Double,
        val south: Double,
        val west: Double,
        val minZoom: Double,
        val maxZoom: Double
    )

    // Приблизительные прямоугольники для первых тестовых пакетов.
    val presets = listOf(
        RegionPreset(
            id = "novokuznetsk",
            title = "Новокузнецк и окрестности",
            north = 53.98, east = 87.55, south = 53.52, west = 86.82,
            minZoom = 7.0, maxZoom = 15.0
        ),
        RegionPreset(
            id = "kemerovo",
            title = "Кемерово и окрестности",
            north = 55.55, east = 86.65, south = 55.05, west = 85.75,
            minZoom = 7.0, maxZoom = 15.0
        ),
        RegionPreset(
            id = "kuzbass_overview",
            title = "Кузбасс — обзорная карта",
            north = 56.5, east = 89.5, south = 52.3, west = 84.0,
            minZoom = 4.0, maxZoom = 9.0
        )
    )
}
