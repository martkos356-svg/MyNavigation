package ru.mynavigation.app.car

import androidx.car.app.CarAppService
import androidx.car.app.Session
import androidx.car.app.Screen
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Template
import androidx.car.app.validation.HostValidator

class NavigationCarAppService : CarAppService() {
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = NavigationSession()
}

private class NavigationSession : Session() {
    override fun onCreateScreen(intent: android.content.Intent): Screen = CarInfoScreen(carContext)
}

private class CarInfoScreen(carContext: androidx.car.app.CarContext) : Screen(carContext) {
    override fun onGetTemplate(): Template = MessageTemplate.Builder(
        "Сервис Android Auto пока работает в демонстрационном режиме. Полноценное ведение по маршруту ещё не реализовано."
    ).setTitle("Моя Навигация").build()
}
