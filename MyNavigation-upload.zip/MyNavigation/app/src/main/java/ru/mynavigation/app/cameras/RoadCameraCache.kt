package ru.mynavigation.app.cameras

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small persistent cache of community-mapped cameras for use when Overpass is unavailable. */
class RoadCameraCache(context: Context) {
    private val prefs = context.getSharedPreferences("road_camera_cache", Context.MODE_PRIVATE)

    data class Snapshot(val cameras: List<RoadCamera>, val savedAtEpochMs: Long)

    fun read(): Snapshot? {
        val raw = prefs.getString(KEY_DATA, null) ?: return null
        return try {
            val root = JSONObject(raw)
            val array = root.optJSONArray("cameras") ?: JSONArray()
            val cameras = buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val kind = runCatching { RoadCameraKind.valueOf(item.optString("kind")) }.getOrNull() ?: continue
                    val lat = item.optDouble("lat", Double.NaN)
                    val lon = item.optDouble("lon", Double.NaN)
                    if (!lat.isFinite() || lat !in -90.0..90.0 || !lon.isFinite() || lon !in -180.0..180.0) continue
                    add(RoadCamera(
                        id = item.optLong("id"), latitude = lat, longitude = lon, kind = kind,
                        description = item.optString("description", "Дорожная камера"),
                        directionDegrees = if (item.isNull("direction")) null else item.optDouble("direction")
                    ))
                }
            }
            Snapshot(cameras, root.optLong("savedAt", 0L))
        } catch (_: Exception) { null }
    }

    fun write(cameras: List<RoadCamera>, savedAtEpochMs: Long = System.currentTimeMillis()) {
        val array = JSONArray()
        cameras.forEach { camera ->
            array.put(JSONObject().apply {
                put("id", camera.id); put("lat", camera.latitude); put("lon", camera.longitude)
                put("kind", camera.kind.name); put("description", camera.description)
                if (camera.directionDegrees == null) put("direction", JSONObject.NULL) else put("direction", camera.directionDegrees)
            })
        }
        prefs.edit().putString(KEY_DATA, JSONObject().put("savedAt", savedAtEpochMs).put("cameras", array).toString()).apply()
    }

    companion object { private const val KEY_DATA = "camera_snapshot_v1" }
}
