package ru.mynavigation.app.routing

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.coroutines.coroutineContext

/**
 * Downloads a prebuilt Valhalla tile extract into the app-private files directory.
 * Only HTTPS is accepted, including every redirect hop. A SHA-256 checksum is
 * strongly recommended and, when supplied, is verified before promotion.
 */
class ValhallaTileInstaller(context: Context) {
    private val destinationDir: File = File(context.getExternalFilesDir(null) ?: context.filesDir, "valhalla").apply {
        if (!exists() && !mkdirs()) throw IOException("Не удалось создать каталог дорожных данных")
    }

    data class InstallResult(val file: File, val bytes: Long, val sha256: String)

    /**
     * [onProgress] is invoked on Dispatchers.IO, not on the main thread.
     * [maxBytes] protects the device from unexpectedly large downloads.
     */
    suspend fun download(
        sourceUrl: String,
        expectedSha256: String? = null,
        maxBytes: Long = DEFAULT_MAX_BYTES,
        onProgress: (downloaded: Long, total: Long) -> Unit = { _, _ -> }
    ): InstallResult = withContext(Dispatchers.IO) {
        require(maxBytes > 0) { "Лимит размера должен быть больше нуля" }
        require(expectedSha256 == null || expectedSha256.matches(Regex("(?i)[0-9a-f]{64}"))) {
            "Контрольная сумма должна содержать 64 шестнадцатеричных символа SHA-256"
        }

        val finalFile = File(destinationDir, TILE_FILE_NAME)
        val partialFile = File(destinationDir, "$TILE_FILE_NAME.part")
        val connection = openHttpsConnection(URL(sourceUrl))

        try {
            connection.connect()
            val status = connection.responseCode
            if (status !in 200..299) throw IOException("Сервер вернул HTTP $status")

            val total = connection.contentLengthLong
            if (total > maxBytes) throw IOException("Файл превышает допустимый размер ${maxBytes / 1024 / 1024} МБ")
            if (total > 0 && destinationDir.usableSpace < total) {
                throw IOException("Недостаточно свободного места для дорожной базы")
            }

            val digest = MessageDigest.getInstance("SHA-256")
            var downloaded = 0L
            connection.inputStream.buffered().use { input ->
                FileOutputStream(partialFile, false).buffered().use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE * 4)
                    while (true) {
                        coroutineContext.ensureActive()
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (downloaded > maxBytes - count) {
                            throw IOException("Загрузка остановлена: превышен допустимый размер файла")
                        }
                        output.write(buffer, 0, count)
                        digest.update(buffer, 0, count)
                        downloaded += count
                        onProgress(downloaded, total)
                    }
                    output.flush()
                }
            }

            if (downloaded == 0L) throw IOException("Сервер вернул пустой файл")
            if (total >= 0 && downloaded != total) {
                throw IOException("Загрузка неполная: ожидалось $total байт, получено $downloaded")
            }

            val actualHash = digest.digest().joinToString("") { "%02x".format(it) }
            if (expectedSha256 != null && !actualHash.equals(expectedSha256, ignoreCase = true)) {
                throw IOException("SHA-256 не совпадает: файл повреждён или изменён")
            }

            promoteFile(partialFile, finalFile)
            InstallResult(finalFile, downloaded, actualHash)
        } catch (error: Throwable) {
            partialFile.delete()
            throw error
        } finally {
            connection.disconnect()
        }
    }

    private fun openHttpsConnection(initialUrl: URL): HttpURLConnection {
        var currentUrl = initialUrl
        repeat(MAX_REDIRECTS + 1) { redirectCount ->
            if (!currentUrl.protocol.equals("https", ignoreCase = true) || currentUrl.userInfo != null) {
                throw IOException("Разрешены только HTTPS-адреса без данных авторизации в URL")
            }
            val connection = (currentUrl.openConnection() as HttpURLConnection).apply {
                connectTimeout = CONNECT_TIMEOUT_MS
                readTimeout = READ_TIMEOUT_MS
                instanceFollowRedirects = false
                requestMethod = "GET"
            }
            connection.connect()
            val status = connection.responseCode
            if (status in REDIRECT_CODES) {
                val location = connection.getHeaderField("Location")
                connection.disconnect()
                if (location.isNullOrBlank()) throw IOException("Сервер перенаправил запрос без адреса Location")
                if (redirectCount == MAX_REDIRECTS) throw IOException("Слишком много перенаправлений")
                currentUrl = URL(currentUrl, location)
            } else {
                return connection
            }
        }
        throw IOException("Не удалось открыть HTTPS-соединение")
    }

    private fun promoteFile(partialFile: File, finalFile: File) {
        val backupFile = File(destinationDir, "$TILE_FILE_NAME.old")
        if (backupFile.exists() && !backupFile.delete()) {
            throw IOException("Не удалось очистить резервный файл дорожной базы")
        }
        val hadPrevious = finalFile.exists()
        if (hadPrevious && !finalFile.renameTo(backupFile)) {
            throw IOException("Не удалось подготовить замену дорожной базы")
        }
        if (!partialFile.renameTo(finalFile)) {
            if (hadPrevious && !backupFile.renameTo(finalFile)) {
                throw IOException("Не удалось сохранить новую базу и восстановить предыдущую")
            }
            throw IOException("Не удалось сохранить дорожную базу")
        }
        backupFile.delete()
    }

    fun installedFile(): File = File(destinationDir, TILE_FILE_NAME)

    fun removeInstalledFile(): Boolean {
        val file = installedFile()
        return !file.exists() || file.delete()
    }

    private companion object {
        const val TILE_FILE_NAME = "valhalla_tiles.tar"
        const val DEFAULT_MAX_BYTES = 2L * 1024 * 1024 * 1024
        const val CONNECT_TIMEOUT_MS = 20_000
        const val READ_TIMEOUT_MS = 60_000
        const val MAX_REDIRECTS = 5
        val REDIRECT_CODES = setOf(301, 302, 303, 307, 308)
    }
}
