package ru.mynavigation.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persists the active route so the location service can continue voice guidance off-screen. */
object RouteSessionStore {
    data class Progress(val maneuverIndex: Int, val maneuverStages: Set<String>, val alertedCameraIds: Set<Long>)
    private const val PREFS = "navigation_session"
    private const val KEY_ROUTE = "active_route_v1"
    private const val KEY_MANEUVER_INDEX = "progress_maneuver_index"
    private const val KEY_MANEUVER_STAGES = "progress_maneuver_stages"
    private const val KEY_ALERTED_CAMERAS = "progress_alerted_cameras"

    fun save(context: Context, route: RouteInfo?) {
        if (route == null) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_ROUTE).apply()
            return
        }
        val root = JSONObject().apply {
            put("distanceKm", route.distanceKm)
            put("durationMin", route.durationMin)
            put("destination", JSONObject().apply {
                put("name", route.destination.name); put("lat", route.destination.lat); put("lon", route.destination.lon)
            })
            put("maneuvers", JSONArray().apply {
                route.maneuvers.forEach { put(JSONObject().put("lat", it.lat).put("lon", it.lon).put("instruction", it.instruction)) }
            })
            put("geometry", JSONArray().apply {
                route.geometry.forEach { put(JSONObject().put("lat", it.lat).put("lon", it.lon)) }
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_ROUTE, root.toString())
            .remove(KEY_MANEUVER_INDEX).remove(KEY_MANEUVER_STAGES).remove(KEY_ALERTED_CAMERAS)
            .apply()
    }

    fun saveProgress(context: Context, progress: Progress) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_MANEUVER_INDEX, progress.maneuverIndex)
            .putStringSet(KEY_MANEUVER_STAGES, progress.maneuverStages)
            .putStringSet(KEY_ALERTED_CAMERAS, progress.alertedCameraIds.map { it.toString() }.toSet())
            .apply()
    }

    fun loadProgress(context: Context): Progress {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Progress(
            prefs.getInt(KEY_MANEUVER_INDEX, 0).coerceAtLeast(0),
            prefs.getStringSet(KEY_MANEUVER_STAGES, emptySet())?.toSet() ?: emptySet(),
            prefs.getStringSet(KEY_ALERTED_CAMERAS, emptySet())?.mapNotNull { it.toLongOrNull() }?.toSet() ?: emptySet()
        )
    }

    fun load(context: Context): RouteInfo? = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ROUTE, null) ?: return null
        val root = JSONObject(raw)
        val dest = root.getJSONObject("destination")
        val maneuversJson = root.optJSONArray("maneuvers") ?: JSONArray()
        val maneuvers = buildList {
            for (i in 0 until maneuversJson.length()) {
                val p = maneuversJson.getJSONObject(i)
                add(RouteManeuver(p.getDouble("lat"), p.getDouble("lon"), p.optString("instruction")))
            }
        }
        val geometryJson = root.optJSONArray("geometry") ?: JSONArray()
        val geometry = buildList {
            for (i in 0 until geometryJson.length()) {
                val p = geometryJson.getJSONObject(i)
                val lat = p.optDouble("lat", Double.NaN)
                val lon = p.optDouble("lon", Double.NaN)
                if (lat in -90.0..90.0 && lon in -180.0..180.0) add(RoutePoint(lat, lon))
            }
        }
        RouteInfo(
            distanceKm = root.optDouble("distanceKm", 0.0),
            durationMin = root.optDouble("durationMin", 0.0),
            destination = Place(dest.optString("name", "Пункт назначения"), dest.getDouble("lat"), dest.getDouble("lon")),
            instructions = maneuvers.map { it.instruction }, geometry = geometry, maneuvers = maneuvers
        ).takeIf { it.destination.lat in -90.0..90.0 && it.destination.lon in -180.0..180.0 }
    }.getOrNull()
}
