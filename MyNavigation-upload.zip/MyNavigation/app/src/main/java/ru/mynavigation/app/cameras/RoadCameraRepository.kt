package ru.mynavigation.app.cameras

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** A mapped roadside camera. OpenStreetMap coverage and tagging are community-maintained. */
enum class RoadCameraKind { SPEED, TRAFFIC_ENFORCEMENT, SURVEILLANCE }

data class RoadCamera(
    val id: Long,
    val latitude: Double,
    val longitude: Double,
    val kind: RoadCameraKind,
    val description: String,
    /** Optional camera facing bearing in degrees clockwise from true north. */
    val directionDegrees: Double? = null
)

class RoadCameraRepository(
    private val endpoint: String = "https://overpass-api.de/api/interpreter"
) {
    private fun parseDirection(raw: String): Double? {
        val value = raw.trim().lowercase()
        value.toDoubleOrNull()?.let { return ((it % 360.0) + 360.0) % 360.0 }
        return when (value) {
            "n", "north" -> 0.0
            "ne", "northeast" -> 45.0
            "e", "east" -> 90.0
            "se", "southeast" -> 135.0
            "s", "south" -> 180.0
            "sw", "southwest" -> 225.0
            "w", "west" -> 270.0
            "nw", "northwest" -> 315.0
            else -> null // Values such as forward/backward are relative to an OSM way and cannot be converted here.
        }
    }

    suspend fun loadNearby(latitude: Double, longitude: Double, radiusMeters: Int = 15_000): List<RoadCamera> =
        withContext(Dispatchers.IO) {
            require(latitude in -90.0..90.0 && longitude in -180.0..180.0) { "Некорректные координаты" }
            require(radiusMeters in 500..50_000) { "Радиус поиска должен быть от 500 до 50000 метров" }
            val around = "around:$radiusMeters,$latitude,$longitude"
            val query = """
                [out:json][timeout:25];
                (
                  node($around)[highway=speed_camera];
                  node($around)[enforcement=maxspeed];
                  node($around)[enforcement=traffic_signals];
                  node($around)[man_made=surveillance];
                );
                out body;
            """.trimIndent()
            val encoded = URLEncoder.encode(query, "UTF-8")
            val connection = (URL("$endpoint?data=$encoded").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 12_000
                readTimeout = 30_000
                setRequestProperty("User-Agent", "MyNavigationAndroid/0.8.1 (OpenStreetMap Overpass camera lookup)")
            }
            try {
                val code = connection.responseCode
                if (code !in 200..299) throw IllegalStateException("Overpass вернул HTTP $code")
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                val elements = JSONObject(body).optJSONArray("elements") ?: return@withContext emptyList()
                val result = LinkedHashMap<Long, RoadCamera>()
                for (i in 0 until elements.length()) {
                    val item = elements.optJSONObject(i) ?: continue
                    if (!item.has("lat") || !item.has("lon")) continue
                    val tags = item.optJSONObject("tags") ?: JSONObject()
                    val kind = when {
                        tags.optString("highway") == "speed_camera" || tags.optString("enforcement") == "maxspeed" -> RoadCameraKind.SPEED
                        tags.optString("enforcement") == "traffic_signals" -> RoadCameraKind.TRAFFIC_ENFORCEMENT
                        tags.optString("man_made") == "surveillance" -> RoadCameraKind.SURVEILLANCE
                        else -> continue
                    }
                    val description = when (kind) {
                        RoadCameraKind.SPEED -> "Камера контроля скорости"
                        RoadCameraKind.TRAFFIC_ENFORCEMENT -> "Камера контроля перекрёстка"
                        RoadCameraKind.SURVEILLANCE -> "Камера наблюдения (назначение не подтверждено)"
                    }
                    val id = item.optLong("id", -1L)
                    val direction = parseDirection(tags.optString("camera:direction").ifBlank { tags.optString("direction") })
                    if (id >= 0) result[id] = RoadCamera(id, item.getDouble("lat"), item.getDouble("lon"), kind, description, direction)
                }
                result.values.toList()
            } finally {
                connection.disconnect()
            }
        }
}
