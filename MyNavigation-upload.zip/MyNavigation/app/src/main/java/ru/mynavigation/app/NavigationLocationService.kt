package ru.mynavigation.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Bundle
import android.speech.tts.TextToSpeech
import ru.mynavigation.app.cameras.RoadCameraCache
import ru.mynavigation.app.cameras.RoadCameraKind
import java.util.Locale
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject
import java.util.concurrent.Executors
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import ru.mynavigation.app.routing.OfflineValhallaRouter

/** Background GPS service. When the Activity is not visible it also issues cached-route maneuver and camera voice alerts. */
class NavigationLocationService : Service(), TextToSpeech.OnInitListener {
    private var locationManager: LocationManager? = null
    private var lastNotificationAt = 0L
    private var stoppedBroadcastSent = false
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var route: RouteInfo? = null
    private var nextManeuverIndex = 0
    private val maneuverStages = mutableSetOf<String>()
    private val alertedCameraIds = mutableSetOf<Long>()
    private var announcedArrival = false
    private var offRouteSamples = 0
    private var rerouteInProgress = false
    private var lastRerouteAt = 0L
    private val rerouteExecutor = Executors.newSingleThreadExecutor()
    private val offlineRouter by lazy { OfflineValhallaRouter(applicationContext) }
    private val mainHandler = Handler(Looper.getMainLooper())
    private val cameraCache by lazy { RoadCameraCache(applicationContext) }
    private var backgroundCameras = emptyList<ru.mynavigation.app.cameras.RoadCamera>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTracking()
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_ROUTE_UPDATED) {
            route = RouteSessionStore.load(this)
            val progress = RouteSessionStore.loadProgress(this)
            nextManeuverIndex = progress.maneuverIndex
            maneuverStages.clear(); maneuverStages.addAll(progress.maneuverStages)
            alertedCameraIds.clear(); alertedCameraIds.addAll(progress.alertedCameraIds)
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_CAMERAS_UPDATED) {
            backgroundCameras = cameraCache.read()?.cameras.orEmpty()
            return START_NOT_STICKY
        }
        createNotificationChannel()
        if (tts == null) tts = TextToSpeech(applicationContext, this)
        route = RouteSessionStore.load(this)
        backgroundCameras = cameraCache.read()?.cameras.orEmpty()
        val savedProgress = RouteSessionStore.loadProgress(this)
        nextManeuverIndex = savedProgress.maneuverIndex
        maneuverStages.clear(); maneuverStages.addAll(savedProgress.maneuverStages)
        alertedCameraIds.clear(); alertedCameraIds.addAll(savedProgress.alertedCameraIds)
        val notification = buildNotification("Ожидание координат GPS")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
        startTracking()
        // Avoid an implicit background restart that could violate Android 14+ while-in-use location rules.
        return START_NOT_STICKY
    }

    private fun startTracking() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) {
            updateNotification("Нет разрешения на геолокацию")
            stopSelf()
            return
        }
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        locationManager = manager
        val provider = try {
            when {
                fine && manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                manager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                else -> null
            }
        } catch (_: Exception) { null }
        if (provider == null) {
            updateNotification("Включите GPS или сетевую геолокацию")
            return
        }
        try {
            manager.requestLocationUpdates(provider, 2000L, 5f, listener, mainLooper)
            manager.getLastKnownLocation(provider)?.let(::publishLocation)
        } catch (_: SecurityException) {
            updateNotification("Нет доступа к GPS")
            stopSelf()
        } catch (e: Exception) {
            updateNotification("GPS недоступен: ${e.javaClass.simpleName}")
        }
    }

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) = publishLocation(location)
        override fun onProviderEnabled(provider: String) { updateNotification("GPS активен") }
        override fun onProviderDisabled(provider: String) { updateNotification("GPS отключён") }
        @Deprecated("Deprecated by Android")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
    }

    private fun publishLocation(location: Location) {
        if (!location.latitude.isFinite() || !location.longitude.isFinite()) return
        val broadcast = Intent(ACTION_LOCATION).setPackage(packageName).apply {
            putExtra(EXTRA_LAT, location.latitude)
            putExtra(EXTRA_LON, location.longitude)
            putExtra(EXTRA_ACCURACY, location.accuracy)
            putExtra(EXTRA_SPEED, location.speed)
            putExtra(EXTRA_TIME, location.time)
            if (location.hasBearing()) putExtra(EXTRA_BEARING, location.bearing)
        }
        sendBroadcast(broadcast)
        if (!MainActivity.activityVisible) processBackgroundGuidance(location)
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastNotificationAt >= 10_000L) {
            lastNotificationAt = now
            val accuracy = if (location.hasAccuracy()) "±${location.accuracy.toInt()} м" else "точность неизвестна"
            updateNotification("GPS активен • $accuracy")
        }
    }


    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS && (tts?.setLanguage(Locale("ru", "RU")) ?: TextToSpeech.LANG_NOT_SUPPORTED) >= TextToSpeech.LANG_AVAILABLE
    }

    /** Voice alerts continue with the last saved route and last downloaded camera snapshot. */
    private fun processBackgroundGuidance(location: Location) {
        if (location.hasAccuracy() && location.accuracy > 80f) return
        val activeRoute = route ?: RouteSessionStore.load(this)?.also { route = it } ?: return
        val destination = Location("destination").apply {
            latitude = activeRoute.destination.lat
            longitude = activeRoute.destination.lon
        }
        if (!announcedArrival && location.distanceTo(destination) <= 35f &&
            (!location.hasAccuracy() || location.accuracy <= 35f)) {
            announcedArrival = true
            speak("Вы прибыли в пункт назначения")
            updateNotification("Прибытие • ${activeRoute.destination.name.take(45)}")
            return
        }
        if (checkBackgroundOffRoute(location, activeRoute)) return
        announceManeuver(location, activeRoute)
        warnAboutCachedCameras(location)
        sendGuidanceProgress()
    }

    /** Detect sustained deviation and prefer an on-device Valhalla route; use OSRM only as fallback. */
    private fun checkBackgroundOffRoute(location: Location, activeRoute: RouteInfo): Boolean {
        if (activeRoute.geometry.size < 2 || (location.hasAccuracy() && location.accuracy > 35f)) {
            offRouteSamples = 0
            return false
        }
        val destination = Location("destination").apply {
            latitude = activeRoute.destination.lat
            longitude = activeRoute.destination.lon
        }
        if (location.distanceTo(destination) < 100f) {
            offRouteSamples = 0
            return false
        }
        val distance = distanceToRouteMeters(location.latitude, location.longitude, activeRoute.geometry)
        if (distance > OFF_ROUTE_THRESHOLD_METERS) offRouteSamples++ else offRouteSamples = 0
        if (offRouteSamples < OFF_ROUTE_REQUIRED_SAMPLES || rerouteInProgress) return false
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastRerouteAt < REROUTE_COOLDOWN_MS) return false
        rerouteInProgress = true
        lastRerouteAt = now
        offRouteSamples = 0
        updateNotification("Отклонение от маршрута • ищу новый путь")
        val destinationPlace = activeRoute.destination
        val startLat = location.latitude
        val startLon = location.longitude
        rerouteExecutor.execute {
            val result = runCatching {
                if (offlineRouter.isInstalled()) {
                    val local = runBlocking(Dispatchers.IO) {
                        offlineRouter.route(startLat, startLon, destinationPlace.lat, destinationPlace.lon)
                    }
                    RouteInfo(
                        distanceKm = local.distanceKm,
                        durationMin = local.durationMinutes,
                        destination = destinationPlace,
                        instructions = local.instructions,
                        geometry = local.geometry.map { RoutePoint(it.lat, it.lon) },
                        maneuvers = local.maneuvers.map { RouteManeuver(it.lat, it.lon, it.instruction) }
                    )
                } else {
                    requestBackgroundOsrmRoute(startLat, startLon, destinationPlace)
                }
            }.recoverCatching { offlineOrOnlineFailure ->
                // If the installed local extract is stale or cannot route this location, try online.
                if (offlineRouter.isInstalled()) requestBackgroundOsrmRoute(startLat, startLon, destinationPlace)
                else throw offlineOrOnlineFailure
            }
            mainHandler.post {
                rerouteInProgress = false
                result.onSuccess { updated ->
                    route = updated
                    nextManeuverIndex = 0
                    maneuverStages.clear()
                    alertedCameraIds.clear()
                    announcedArrival = false
                    RouteSessionStore.save(this, updated)
                    RouteSessionStore.saveProgress(this, RouteSessionStore.Progress(0, emptySet(), emptySet()))
                    speak("Маршрут перестроен")
                    updateNotification("Маршрут перестроен • ${updated.distanceKm.toInt()} км")
                    sendBroadcast(Intent(ACTION_ROUTE_RECALCULATED).setPackage(packageName))
                }.onFailure {
                    updateNotification("Не удалось перестроить маршрут • продолжаю прежний")
                }
            }
        }
        return true
    }

    private fun requestBackgroundOsrmRoute(lat: Double, lon: Double, destination: Place): RouteInfo {
        val url = URL("https://router.project-osrm.org/route/v1/driving/$lon,$lat;${destination.lon},${destination.lat}?overview=full&geometries=geojson&steps=true")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 12_000
            setRequestProperty("User-Agent", "MyNavigation-Android/0.8.3 (prototype)")
        }
        try {
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("OSRM HTTP $code")
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            if (root.optString("code") != "Ok") throw IllegalStateException(root.optString("message", "маршрут не найден"))
            val routes = root.getJSONArray("routes")
            if (routes.length() == 0) throw IllegalStateException("маршрут не найден")
            val r = routes.getJSONObject(0)
            val coords = r.optJSONObject("geometry")?.optJSONArray("coordinates") ?: throw IllegalStateException("нет геометрии маршрута")
            val geometry = buildList {
                for (i in 0 until coords.length()) {
                    val pair = coords.getJSONArray(i)
                    if (pair.length() >= 2) add(RoutePoint(pair.getDouble(1), pair.getDouble(0)))
                }
            }
            val maneuvers = mutableListOf<RouteManeuver>()
            val legs = r.optJSONArray("legs")
            if (legs != null) for (li in 0 until legs.length()) {
                val steps = legs.getJSONObject(li).optJSONArray("steps") ?: continue
                for (si in 0 until steps.length()) {
                    val step = steps.getJSONObject(si)
                    val maneuver = step.optJSONObject("maneuver") ?: continue
                    val point = maneuver.optJSONArray("location") ?: continue
                    if (point.length() < 2) continue
                    val instruction = backgroundInstruction(maneuver.optString("type"), maneuver.optString("modifier"), step.optString("name"))
                    if (instruction.isNotBlank()) maneuvers += RouteManeuver(point.getDouble(1), point.getDouble(0), instruction)
                }
            }
            return RouteInfo(r.getDouble("distance") / 1000.0, r.getDouble("duration") / 60.0,
                destination, maneuvers.map { it.instruction }, geometry, maneuvers)
        } finally { connection.disconnect() }
    }

    private fun backgroundInstruction(type: String, modifier: String, road: String): String {
        val direction = when (modifier.lowercase(Locale.ROOT)) {
            "uturn", "uturn left", "uturn right" -> "развернитесь"
            "sharp left" -> "резко поверните налево"
            "left" -> "поверните налево"
            "slight left" -> "плавно поверните налево"
            "sharp right" -> "резко поверните направо"
            "right" -> "поверните направо"
            "slight right" -> "плавно поверните направо"
            "straight" -> "продолжайте прямо"
            "exit" -> "съезжайте"
            else -> when (type.lowercase(Locale.ROOT)) {
                "depart" -> "начните движение"
                "arrive" -> "прибытие в пункт назначения"
                "roundabout", "rotary" -> "на круговом движении следуйте указателям"
                "merge" -> "перестройтесь"
                else -> "продолжайте движение"
            }
        }
        return if (road.isBlank()) direction else "$direction на ${road.trim()}"
    }

    /** Local equirectangular projection is sufficient for short off-route distance checks. */
    private fun distanceToRouteMeters(lat: Double, lon: Double, points: List<RoutePoint>): Double {
        val cosLat = kotlin.math.cos(Math.toRadians(lat))
        fun xy(p: RoutePoint) = Pair((p.lon - lon) * 111_320.0 * cosLat, (p.lat - lat) * 110_540.0)
        var best = Double.POSITIVE_INFINITY
        for (i in 0 until points.lastIndex) {
            val (ax, ay) = xy(points[i]); val (bx, by) = xy(points[i + 1])
            val dx = bx - ax; val dy = by - ay
            val len = dx * dx + dy * dy
            val t = if (len < 1e-9) 0.0 else ((-ax * dx - ay * dy) / len).coerceIn(0.0, 1.0)
            best = minOf(best, kotlin.math.hypot(ax + t * dx, ay + t * dy))
        }
        return best
    }

    private fun announceManeuver(location: Location, activeRoute: RouteInfo) {
        while (nextManeuverIndex < activeRoute.maneuvers.size) {
            val index = nextManeuverIndex
            val maneuver = activeRoute.maneuvers[index]
            val target = Location("maneuver").apply { latitude = maneuver.lat; longitude = maneuver.lon }
            val meters = location.distanceTo(target)
            when {
                meters <= 50f && maneuverStages.add("$index:50") -> speak(maneuver.instruction)
                meters <= 200f && maneuverStages.add("$index:200") -> speak("Через двести метров: ${maneuver.instruction}")
                meters <= 700f && maneuverStages.add("$index:700") -> speak("Через семьсот метров: ${maneuver.instruction}")
            }
            val passed = meters <= 25f
            if (passed) { nextManeuverIndex++; continue }
            break
        }
    }

    private fun warnAboutCachedCameras(location: Location) {
        backgroundCameras.forEach { camera ->
            if (camera.kind == RoadCameraKind.SURVEILLANCE) return@forEach
            val target = Location("camera").apply { latitude = camera.latitude; longitude = camera.longitude }
            val distance = location.distanceTo(target)
            if (distance > 1_200f) alertedCameraIds.remove(camera.id)
            val directionMatches = camera.directionDegrees == null || !location.hasBearing() ||
                location.speed < 2f || angularDifference(location.bearing.toDouble(), camera.directionDegrees) <= 70.0
            if (distance <= 600f && directionMatches && alertedCameraIds.add(camera.id)) {
                val message = if (camera.kind == RoadCameraKind.SPEED) "Впереди камера контроля скорости" else "Впереди камера контроля перекрёстка"
                speak(message)
            }
        }
    }

    private fun sendGuidanceProgress() {
        RouteSessionStore.saveProgress(this, RouteSessionStore.Progress(nextManeuverIndex, maneuverStages.toSet(), alertedCameraIds.toSet()))
        sendBroadcast(Intent(ACTION_GUIDANCE_PROGRESS).setPackage(packageName).apply {
            putExtra(EXTRA_MANEUVER_INDEX, nextManeuverIndex)
            putExtra(EXTRA_MANEUVER_STAGES, maneuverStages.toTypedArray())
            putExtra(EXTRA_ALERTED_CAMERA_IDS, alertedCameraIds.toLongArray())
        })
    }

    private fun angularDifference(a: Double, b: Double): Double = kotlin.math.abs(((a - b + 540.0) % 360.0) - 180.0)

    private fun speak(message: String) {
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_ADD, null, "background-${System.currentTimeMillis()}")
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Фоновая навигация", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "Постоянное уведомление во время GPS-навигации"
                }
            )
        }
    }

    private fun buildNotification(message: String): Notification {
        val stopIntent = Intent(this, NavigationLocationService::class.java).setAction(ACTION_STOP)
        val immutableFlag = if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        val stopPending = PendingIntent.getService(
            this, 2, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag
        )
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val contentPending = openIntent?.let {
            PendingIntent.getActivity(this, 1, it, PendingIntent.FLAG_UPDATE_CURRENT or immutableFlag)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Моя Навигация • ведение активно")
            .setContentText(message)
            .setContentIntent(contentPending)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Остановить GPS", stopPending)
            .build()
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    @Suppress("DEPRECATION")
    private fun stopTracking() {
        try { locationManager?.removeUpdates(listener) } catch (_: SecurityException) { }
        locationManager = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        if (!stoppedBroadcastSent) {
            stoppedBroadcastSent = true
            sendBroadcast(Intent(ACTION_STOPPED).setPackage(packageName))
        }
    }

    override fun onDestroy() {
        stopTracking()
        rerouteExecutor.shutdownNow()
        runCatching { offlineRouter.close() }
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "ru.mynavigation.app.action.START_GUIDANCE"
        const val ACTION_STOP = "ru.mynavigation.app.action.STOP_GUIDANCE"
        const val ACTION_LOCATION = "ru.mynavigation.app.action.LOCATION_UPDATE"
        const val ACTION_STOPPED = "ru.mynavigation.app.action.GUIDANCE_STOPPED"
        const val ACTION_GUIDANCE_PROGRESS = "ru.mynavigation.app.action.GUIDANCE_PROGRESS"
        const val ACTION_ROUTE_UPDATED = "ru.mynavigation.app.action.ROUTE_UPDATED"
        const val ACTION_CAMERAS_UPDATED = "ru.mynavigation.app.action.CAMERAS_UPDATED"
        const val ACTION_ROUTE_RECALCULATED = "ru.mynavigation.app.action.ROUTE_RECALCULATED"
        private const val OFF_ROUTE_THRESHOLD_METERS = 90.0
        private const val OFF_ROUTE_REQUIRED_SAMPLES = 3
        private const val REROUTE_COOLDOWN_MS = 45_000L
        const val EXTRA_LAT = "lat"
        const val EXTRA_LON = "lon"
        const val EXTRA_ACCURACY = "accuracy"
        const val EXTRA_SPEED = "speed"
        const val EXTRA_BEARING = "bearing"
        const val EXTRA_TIME = "time"
        const val EXTRA_MANEUVER_INDEX = "maneuver_index"
        const val EXTRA_MANEUVER_STAGES = "maneuver_stages"
        const val EXTRA_ALERTED_CAMERA_IDS = "alerted_camera_ids"
        private const val CHANNEL_ID = "navigation_location"
        private const val NOTIFICATION_ID = 7101
    }
}
