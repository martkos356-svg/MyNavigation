package ru.mynavigation.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.json.JSONObject
import org.maplibre.android.MapLibre
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapView
import org.maplibre.geojson.Feature
import org.maplibre.geojson.FeatureCollection
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.CircleLayer
import org.maplibre.android.style.layers.PropertyFactory.lineCap
import org.maplibre.android.style.layers.PropertyFactory.lineColor
import org.maplibre.android.style.layers.PropertyFactory.lineJoin
import org.maplibre.android.style.layers.PropertyFactory.lineWidth
import org.maplibre.android.style.layers.PropertyFactory.circleColor
import org.maplibre.android.style.layers.PropertyFactory.circleRadius
import org.maplibre.android.style.layers.PropertyFactory.circleStrokeColor
import org.maplibre.android.style.layers.PropertyFactory.circleStrokeWidth
import org.maplibre.android.style.sources.GeoJsonSource
import ru.mynavigation.app.cameras.RoadCamera
import ru.mynavigation.app.cameras.RoadCameraKind
import ru.mynavigation.app.cameras.RoadCameraRepository
import ru.mynavigation.app.cameras.RoadCameraCache
import ru.mynavigation.app.offline.OfflineMapConfig
import ru.mynavigation.app.offline.OfflineMapDownloader
import ru.mynavigation.app.routing.OfflineValhallaRouter
import ru.mynavigation.app.routing.ValhallaTileInstaller
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.Locale

data class Place(val name: String, val lat: Double, val lon: Double)
data class RoutePoint(val lat: Double, val lon: Double)
data class RouteManeuver(val lat: Double, val lon: Double, val instruction: String)
data class RouteInfo(
    val distanceKm: Double,
    val durationMin: Double,
    val destination: Place,
    val instructions: List<String> = emptyList(),
    val geometry: List<RoutePoint> = emptyList(),
    val maneuvers: List<RouteManeuver> = emptyList()
)

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var mapView: MapView
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var voice: TextToSpeech
    private var currentLocation: Location? = null
    private var mapReady = false
    private var currentRoute: RouteInfo? = null
    private var activeRouteMode: String = "Маршрут"
    private var destinationRouteJob: Job? = null
    private var guidanceActive = false
    private var locationReceiverRegistered = false
    private var lastCameraFollowAt = 0L
    private var lastRerouteAt = 0L
    private var offRouteSamples = 0
    private var rerouteInProgress = false
    private var hasAnnouncedArrival = false
    private var nextManeuverIndex = 0
    private val announcedManeuverStages = mutableSetOf<String>()
    private var lastManeuverDistanceMeters: Float? = null
    private var pendingRouteGeometry: List<RoutePoint> = emptyList()
    private val offlineRouter by lazy { OfflineValhallaRouter(applicationContext) }
    private val cameraRepository by lazy { RoadCameraRepository() }
    private val cameraCache by lazy { RoadCameraCache(applicationContext) }
    private val offlinePlaceIndex by lazy { OfflinePlaceIndex(applicationContext) }
    private val offlineGazetteer by lazy { OfflineGazetteer(applicationContext) }
    private var roadCameras: List<RoadCamera> = emptyList()
    private var cameraFetchInProgress = false
    private var lastCameraFetchAt = 0L
    private var lastCameraFetchLocation: Location? = null
    private val alertedCameraIds = mutableSetOf<Long>()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val prefs by lazy { getSharedPreferences("mynav", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        voice = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101820.toInt())
            setPadding(12, 10, 12, 8)
        }
        root.addView(TextView(this).apply {
            text = "МОЯ НАВИГАЦИЯ  •  КУЗБАСС"; textSize = 20f
            setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER_VERTICAL
            setPadding(6, 6, 6, 10)
        })
        search = EditText(this).apply {
            hint = "Введите адрес или место назначения"; setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFFB0BEC5.toInt())
            setPadding(14, 8, 14, 8); setBackgroundColor(0xFF263746.toInt())
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 52))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(actionButton("Найти") { findDestination() }, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(actionButton("Моё место") { locateMe() }, LinearLayout.LayoutParams(0, 48, 1f))
        actions.addView(actionButton("Избранное") { showFavorites() }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(actions)
        root.addView(actionButton("Установить офлайн-каталог улиц и адресов (SQLite)") { chooseOfflineGazetteer() }, LinearLayout.LayoutParams(-1, 44))
        root.addView(actionButton("Офлайн-карты Кузбасса") { showOfflineMaps() }, LinearLayout.LayoutParams(-1, 44))
        root.addView(actionButton("Дорожная база для офлайн-маршрутов") { showRoutingInstaller() }, LinearLayout.LayoutParams(-1, 44))
        root.addView(actionButton("Камеры рядом: скорость, перекрёстки, наблюдение") { loadNearbyCameras(force = true) }, LinearLayout.LayoutParams(-1, 44))
        val guidanceActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        guidanceActions.addView(actionButton("Начать слежение") { startGuidance() }, LinearLayout.LayoutParams(0, 46, 1f))
        guidanceActions.addView(actionButton("Остановить") { stopGuidance() }, LinearLayout.LayoutParams(0, 46, 1f))
        root.addView(guidanceActions)
        status = TextView(this).apply {
            text = "Готово. При установленной дорожной базе маршруты строятся офлайн; новые адреса ищутся онлайн, ранее выбранные места доступны офлайн."
            textSize = 13f; setTextColor(0xFFD5DFEA.toInt()); setPadding(6, 8, 6, 8)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "Картографические данные и офлайн-каталог: © OpenStreetMap contributors"
            textSize = 10f; setTextColor(0xFFB0BEC5.toInt()); setPadding(6, 2, 6, 4)
        })
        mapView = MapView(this)
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))
        val destinationActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        destinationActions.addView(actionButton("Сохранить адрес") { saveCurrentDestination() }, LinearLayout.LayoutParams(0, 48, 1f))
        destinationActions.addView(actionButton("Сбросить маршрут") { clearDestination() }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(destinationActions)
        setContentView(root)
        cameraCache.read()?.let { snapshot ->
            roadCameras = snapshot.cameras
            lastCameraFetchAt = android.os.SystemClock.elapsedRealtime()
            status.text = "Загружен локальный список камер: ${roadCameras.size}. Дата сохранения: ${java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("ru")).format(java.util.Date(snapshot.savedAtEpochMs))}. Данные могут быть устаревшими."
        }
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { map ->
            val ready: () -> Unit = {
                mapReady = true
                map.cameraPosition = CameraPosition.Builder().target(LatLng(53.7575, 87.1361)).zoom(11.0).build()
                updateGpsMarker(currentLocation)
                currentRoute?.destination?.let { updateDestinationMarker(it) }
                drawRoadCameras(roadCameras)
            }
            if (OfflineMapConfig.STYLE_URL.startsWith("https://")) {
                // Один и тот же style URL используется для отображения и офлайн-пакетов.
                map.setStyle(OfflineMapConfig.STYLE_URL) { ready(); drawRoute(pendingRouteGeometry) }
            } else {
                // Только для разработки. Стандартный OSM tile server не используется
                // для массового предварительного скачивания офлайн-пакетов.
                val styleJson = """{"version":8,"sources":{"osm":{"type":"raster","tiles":["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],"tileSize":256,"attribution":"© OpenStreetMap contributors"}},"layers":[{"id":"osm","type":"raster","source":"osm"}]}"""
                map.setStyle(styleJson) { ready(); drawRoute(pendingRouteGeometry); updateGpsMarker(currentLocation) }
            }
        }
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { findDestination(); true } else false
        }
        requestLocation()
    }


    private fun showOfflineMaps() {
        val downloader = OfflineMapDownloader(this)
        val options = arrayOf("Скачать Новокузнецк и окрестности", "Скачать Кемерово и окрестности", "Скачать обзорную карту Кузбасса", "Показать сохранённые карты")
        AlertDialog.Builder(this)
            .setTitle("Офлайн-карты")
            .setItems(options) { _, which ->
                if (which == 3) {
                    downloader.listSaved(
                        onResult = { rows ->
                            status.text = if (rows.isEmpty()) "Сохранённых офлайн-регионов пока нет." else "Сохранённые регионы:\n" + rows.joinToString("\n")
                        },
                        reportError = { error -> status.text = "Не удалось получить список карт: $error" }
                    )
                } else {
                    val preset = OfflineMapConfig.presets[which]
                    downloader.download(
                        preset = preset,
                        onProgress = { message -> status.text = message },
                        reportError = { error ->
                            status.text = error
                            AlertDialog.Builder(this).setTitle("Офлайн-карты")
                                .setMessage(error + "\n\nПока провайдер карт не настроен, загрузка не запускается. Публичный сервер тайлов OpenStreetMap нельзя использовать для массовой предварительной загрузки.")
                                .setPositiveButton("Понятно", null).show()
                        }
                    )
                }
            }
            .setNegativeButton("Закрыть", null)
            .show()
    }

    private fun showRoutingInstaller() {
        val urlInput = EditText(this).apply {
            hint = "HTTPS-ссылка на valhalla_kuzbass.tar"
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val hashInput = EditText(this).apply {
            hint = "SHA-256 (необязательно)"
            setSingleLine(true)
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 8, 28, 0)
            addView(urlInput)
            addView(hashInput)
        }
        AlertDialog.Builder(this)
            .setTitle("Установка дорожной базы")
            .setMessage("Укажите HTTPS-адрес заранее собранного Valhalla TAR. Готовая база Кузбасса пока не размещена на сервере проекта.")
            .setView(content)
            .setPositiveButton("Загрузить", null)
            .setNegativeButton("Отмена", null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val url = urlInput.text.toString().trim()
                        val hash = hashInput.text.toString().trim().ifBlank { null }
                        if (!url.startsWith("https://", true)) {
                            urlInput.error = "Нужна HTTPS-ссылка"
                            return@setOnClickListener
                        }
                        dialog.dismiss()
                        status.text = "Загружаю дорожную базу…"
                        scope.launch {
                            try {
                                val result = ValhallaTileInstaller(this@MainActivity).download(
                                    sourceUrl = url,
                                    expectedSha256 = hash,
                                    onProgress = { downloaded, total ->
                                        runOnUiThread {
                                            val percent = if (total > 0) (downloaded * 100 / total).toInt() else -1
                                            status.text = if (percent >= 0) "Загрузка дорожной базы: $percent%" else "Загружено ${downloaded / 1_048_576} МБ"
                                        }
                                    }
                                )
                                offlineRouter.close()
                                status.text = "Дорожная база установлена (${result.bytes / 1_048_576} МБ). Офлайн-маршруты доступны."
                            } catch (e: Exception) {
                                status.text = "Не удалось установить дорожную базу: ${e.message ?: "ошибка загрузки"}"
                            }
                        }
                    }
                }
                dialog.show()
            }
    }

    /** Foreground-only GPS guidance: updates the car position and follows it on the map. */
    private fun startGuidance() {
        if (currentRoute == null || (currentRoute?.geometry?.size ?: 0) < 2) {
            status.text = "Сначала найдите пункт назначения и постройте маршрут."
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 41)
            status.text = "Разрешите доступ к геолокации, затем нажмите «Начать слежение»."
            return
        }
        guidanceActive = true
        alertedCameraIds.clear()
        loadNearbyCameras(force = false)
        offRouteSamples = 0
        hasAnnouncedArrival = false
        nextManeuverIndex = 0
        announcedManeuverStages.clear()
        lastManeuverDistanceMeters = null
        try {
            ContextCompat.startForegroundService(
                this,
                Intent(this, NavigationLocationService::class.java).setAction(NavigationLocationService.ACTION_START)
            )
            currentLocation?.let { onLiveLocation(it) }
            status.text = "Навигация активна. При свёрнутом приложении продолжаются голосовые подсказки по сохранённому маршруту и предупреждения по локальной базе камер."
            voice.speak("Слежение за местоположением включено", TextToSpeech.QUEUE_FLUSH, null, "guidance-start")
        } catch (e: Exception) {
            guidanceActive = false
            status.text = "Не удалось запустить фоновый GPS: ${e.message ?: "ошибка службы"}"
        }
    }

    private fun stopGuidance() {
        guidanceActive = false
        offRouteSamples = 0
        rerouteInProgress = false
        stopLocationService()
        status.text = "Слежение за GPS остановлено."
    }

    private fun stopLocationService() {
        stopService(Intent(this, NavigationLocationService::class.java))
    }

    private val locationReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == NavigationLocationService.ACTION_STOPPED) {
                guidanceActive = false
                status.text = "Фоновое GPS-слежение остановлено."
                return
            }
            if (intent?.action == NavigationLocationService.ACTION_GUIDANCE_PROGRESS) {
                nextManeuverIndex = maxOf(nextManeuverIndex, intent.getIntExtra(NavigationLocationService.EXTRA_MANEUVER_INDEX, 0))
                intent.getStringArrayExtra(NavigationLocationService.EXTRA_MANEUVER_STAGES)?.let { announcedManeuverStages.addAll(it) }
                intent.getLongArrayExtra(NavigationLocationService.EXTRA_ALERTED_CAMERA_IDS)?.let { alertedCameraIds.addAll(it.toList()) }
                return
            }
            if (intent?.action == NavigationLocationService.ACTION_ROUTE_RECALCULATED) {
                RouteSessionStore.load(this@MainActivity)?.let { updated ->
                    currentRoute = updated
                    pendingRouteGeometry = updated.geometry
                    if (mapReady) drawRoute(updated.geometry)
                    nextManeuverIndex = 0
                    announcedManeuverStages.clear()
                    hasAnnouncedArrival = false
                    activeRouteMode = "Перестроен в фоне"
                status.text = "Маршрут перестроен в фоне • ${"%.1f".format(updated.distanceKm)} км"
                }
                return
            }
            if (intent?.action != NavigationLocationService.ACTION_LOCATION) return
            val lat = intent.getDoubleExtra(NavigationLocationService.EXTRA_LAT, Double.NaN)
            val lon = intent.getDoubleExtra(NavigationLocationService.EXTRA_LON, Double.NaN)
            if (!lat.isFinite() || !lon.isFinite()) return
            val location = Location("navigation-service").apply {
                latitude = lat
                longitude = lon
                accuracy = intent.getFloatExtra(NavigationLocationService.EXTRA_ACCURACY, 999f)
                speed = intent.getFloatExtra(NavigationLocationService.EXTRA_SPEED, 0f)
                if (intent.hasExtra(NavigationLocationService.EXTRA_BEARING)) {
                    bearing = intent.getFloatExtra(NavigationLocationService.EXTRA_BEARING, 0f)
                }
                time = intent.getLongExtra(NavigationLocationService.EXTRA_TIME, System.currentTimeMillis())
            }
            onLiveLocation(location)
        }
    }

    private fun registerLocationReceiver() {
        if (locationReceiverRegistered) return
        ContextCompat.registerReceiver(
            this, locationReceiver,
            IntentFilter().apply {
                addAction(NavigationLocationService.ACTION_LOCATION)
                addAction(NavigationLocationService.ACTION_STOPPED)
                addAction(NavigationLocationService.ACTION_GUIDANCE_PROGRESS)
                addAction(NavigationLocationService.ACTION_ROUTE_RECALCULATED)
            },
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        locationReceiverRegistered = true
    }

    private fun unregisterLocationReceiver() {
        if (!locationReceiverRegistered) return
        runCatching { unregisterReceiver(locationReceiver) }
        locationReceiverRegistered = false
    }

    private fun onLiveLocation(location: Location) {
        if (!location.latitude.isFinite() || !location.longitude.isFinite()) return
        currentLocation = location
        updateGpsMarker(location)
        maybeRefreshRoadCameras(location)
        if (guidanceActive) {
            if (mapReady) {
                val now = android.os.SystemClock.elapsedRealtime()
                if (now - lastCameraFollowAt >= 1500L) {
                    lastCameraFollowAt = now
                    mapView.getMapAsync { map ->
                        map.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLng(LatLng(location.latitude, location.longitude)))
                    }
                }
            }
            checkRouteProgress(location)
        }
    }

    /** Checks distance to the route, announces arrival, and requests a new route after a sustained deviation. */
    private fun checkRouteProgress(location: Location) {
        val route = currentRoute ?: return
        val destination = Location("destination").apply {
            latitude = route.destination.lat
            longitude = route.destination.lon
        }
        announceNextManeuver(location, route)
        checkRoadCameraWarnings(location)
        if (route.geometry.size >= 2) {
            val remainingKm = remainingRouteDistanceKm(location, route.geometry)
            status.text = routeProgressText(route, remainingKm)
        }
        if (!hasAnnouncedArrival && location.distanceTo(destination) <= 35f &&
            (location.accuracy <= 0f || location.accuracy <= 35f)) {
            hasAnnouncedArrival = true
            voice.speak("Вы прибыли в пункт назначения", TextToSpeech.QUEUE_FLUSH, null, "arrival")
            status.text = "Вы прибыли: ${route.destination.name}"
            return
        }
        if (route.geometry.size < 2 || rerouteInProgress) return
        // Ignore imprecise or stale fixes: they can falsely trigger repeated detours.
        if ((location.hasAccuracy() && location.accuracy > REROUTE_MAX_ACCURACY_METERS) ||
            (location.time > 0L && System.currentTimeMillis() - location.time > REROUTE_MAX_FIX_AGE_MS)) {
            offRouteSamples = 0
            return
        }
        if (location.distanceTo(destination) <= REROUTE_DESTINATION_GUARD_METERS) {
            offRouteSamples = 0
            return
        }
        val distance = distanceToRouteMeters(location.latitude, location.longitude, route.geometry)
        if (distance > OFF_ROUTE_THRESHOLD_METERS) {
            offRouteSamples++
            if (offRouteSamples >= OFF_ROUTE_REQUIRED_SAMPLES) requestReroute(location)
        } else {
            offRouteSamples = 0
        }
    }

    /** Estimates remaining route length from the nearest geometry vertex to the destination. */
    private fun remainingRouteDistanceKm(location: Location, points: List<RoutePoint>): Double {
        if (points.size < 2) return 0.0
        var nearestIndex = 0
        var nearestMeters = Float.MAX_VALUE
        points.forEachIndexed { index, point ->
            val candidate = Location("route-point").apply {
                latitude = point.lat
                longitude = point.lon
            }
            val distance = location.distanceTo(candidate)
            if (distance < nearestMeters) {
                nearestMeters = distance
                nearestIndex = index
            }
        }
        var remainingMeters = 0.0
        for (index in nearestIndex until points.lastIndex) {
            val start = points[index]
            val end = points[index + 1]
            val result = FloatArray(1)
            Location.distanceBetween(start.lat, start.lon, end.lat, end.lon, result)
            remainingMeters += result[0].toDouble()
        }
        return remainingMeters / 1000.0
    }

    /** Keeps route mode and an approximate remaining ETA visible during live GPS updates. */
    private fun routeProgressText(route: RouteInfo, remainingKm: Double): String {
        val remainingMinutes = RouteProgressMath.estimateRemainingMinutes(
            route.distanceKm, route.durationMin, remainingKm
        )
        val eta = remainingMinutes?.let { "\nОсталось примерно $it мин." }.orEmpty()
        val next = route.maneuvers.getOrNull(nextManeuverIndex)?.instruction
            ?.let { "\nДалее: $it" }.orEmpty()
        return "До ${route.destination.name}\nОсталось около ${"%.1f".format(Locale("ru"), remainingKm)} км$eta\n$activeRouteMode$next"
    }

    /** Local equirectangular projection is sufficiently accurate for the short off-route threshold. */
    private fun distanceToRouteMeters(lat: Double, lon: Double, points: List<RoutePoint>): Double {
        val earthRadius = 6_371_000.0
        val lat0 = Math.toRadians(lat)
        val cosLat = kotlin.math.cos(lat0).coerceAtLeast(0.01)
        fun xy(point: RoutePoint): Pair<Double, Double> {
            val x = Math.toRadians(point.lon - lon) * earthRadius * cosLat
            val y = Math.toRadians(point.lat - lat) * earthRadius
            return x to y
        }
        var bestSquared = Double.POSITIVE_INFINITY
        for (i in 0 until points.lastIndex) {
            val (ax, ay) = xy(points[i])
            val (bx, by) = xy(points[i + 1])
            val dx = bx - ax
            val dy = by - ay
            val lengthSquared = dx * dx + dy * dy
            val t = if (lengthSquared <= 1e-6) 0.0 else ((-ax * dx - ay * dy) / lengthSquared).coerceIn(0.0, 1.0)
            val px = ax + t * dx
            val py = ay + t * dy
            bestSquared = minOf(bestSquared, px * px + py * py)
        }
        return kotlin.math.sqrt(bestSquared)
    }

    private fun requestReroute(location: Location) {
        val destination = currentRoute?.destination ?: return
        val requestedDestination = destination
        val now = android.os.SystemClock.elapsedRealtime()
        if (rerouteInProgress || now - lastRerouteAt < REROUTE_COOLDOWN_MS) return
        rerouteInProgress = true
        lastRerouteAt = now
        offRouteSamples = 0
        status.text = "Вы отклонились от маршрута. Перестраиваю путь…"
        scope.launch {
            try {
                var mode = "ОНЛАЙН • OSRM"
                val updated = if (offlineRouter.isInstalled()) {
                    try {
                        val local = offlineRouter.route(location.latitude, location.longitude, destination.lat, destination.lon)
                        mode = "ОФЛАЙН • Valhalla"
                        RouteInfo(local.distanceKm, local.durationMinutes, destination, local.instructions,
                            local.geometry.map { RoutePoint(it.lat, it.lon) },
                            local.maneuvers.map { RouteManeuver(it.lat, it.lon, it.instruction) })
                    } catch (_: Exception) {
                        mode = "ОНЛАЙН • OSRM (резерв)"
                        withContext(Dispatchers.IO) { buildRoute(location.latitude, location.longitude, destination) }
                    }
                } else {
                    withContext(Dispatchers.IO) { buildRoute(location.latitude, location.longitude, destination) }
                }
                // A route request may finish after the user cleared or changed the destination.
                val stillSelected = currentRoute?.destination?.let {
                    it.lat == requestedDestination.lat && it.lon == requestedDestination.lon
                } == true
                if (!stillSelected || updated.geometry.size < 2) return@launch
                currentRoute = updated
                activeRouteMode = mode
                RouteSessionStore.save(applicationContext, updated)
                if (guidanceActive) startService(Intent(this@MainActivity, NavigationLocationService::class.java).setAction(NavigationLocationService.ACTION_ROUTE_UPDATED))
                pendingRouteGeometry = updated.geometry
                drawRoute(updated.geometry)
                hasAnnouncedArrival = false
                nextManeuverIndex = 0
                announcedManeuverStages.clear()
                lastManeuverDistanceMeters = null
                status.text = "Маршрут перестроен • $mode\n${"%.1f".format(updated.distanceKm)} км • около ${updated.durationMin.toInt()} мин."
                voice.speak("Маршрут перестроен", TextToSpeech.QUEUE_FLUSH, null, "reroute")
            } catch (e: Exception) {
                status.text = "Не удалось перестроить маршрут: ${e.message ?: "нет соединения"}. Продолжаю показывать прежний путь."
            } finally {
                rerouteInProgress = false
            }
        }
    }

    /** Loads community-mapped cameras around the current position; this is not a live CCTV feed. */
    private fun loadNearbyCameras(force: Boolean) {
        val location = currentLocation
        if (location == null) {
            requestLocation()
            status.text = "Сначала получите координаты GPS, затем повторите поиск камер."
            return
        }
        val now = android.os.SystemClock.elapsedRealtime()
        val previous = lastCameraFetchLocation
        if (cameraFetchInProgress) return
        if (!force && lastCameraFetchAt > 0L && now - lastCameraFetchAt < CAMERA_REFRESH_INTERVAL_MS &&
            previous != null && previous.distanceTo(location) < CAMERA_REFRESH_DISTANCE_METERS) return
        cameraFetchInProgress = true
        status.text = "Ищу отмеченные на OpenStreetMap камеры в радиусе 15 км…"
        scope.launch {
            try {
                val found = cameraRepository.loadNearby(location.latitude, location.longitude)
                roadCameras = found
                cameraCache.write(found)
                if (guidanceActive) startService(Intent(this@MainActivity, NavigationLocationService::class.java).setAction(NavigationLocationService.ACTION_CAMERAS_UPDATED))
                lastCameraFetchAt = android.os.SystemClock.elapsedRealtime()
                lastCameraFetchLocation = Location(location)
                drawRoadCameras(found)
                val speed = found.count { it.kind == RoadCameraKind.SPEED }
                val enforcement = found.count { it.kind == RoadCameraKind.TRAFFIC_ENFORCEMENT }
                val surveillance = found.count { it.kind == RoadCameraKind.SURVEILLANCE }
                status.text = "Камеры в радиусе 15 км (данные OpenStreetMap):\n" +
                    "Контроль скорости: $speed • Перекрёстки: $enforcement • Наблюдение: $surveillance\n" +
                    "Покрытие неполное; отсутствие отметки не означает отсутствие камеры."
                if (found.isEmpty()) voice.speak("В базе OpenStreetMap рядом камеры не отмечены", TextToSpeech.QUEUE_FLUSH, null, "camera-none")
            } catch (e: Exception) {
                val cached = cameraCache.read()
                if (cached != null) {
                    roadCameras = cached.cameras
                    drawRoadCameras(roadCameras)
                    val ageDays = ((System.currentTimeMillis() - cached.savedAtEpochMs).coerceAtLeast(0L) / 86_400_000L)
                    status.text = "Сеть недоступна. Используется сохранённый список камер (${roadCameras.size}, сохранён $ageDays дн. назад). Данные могут быть устаревшими."
                } else {
                    status.text = "Не удалось загрузить камеры: ${e.message ?: "сервер временно недоступен"}. Локальной копии пока нет."
                }
            } finally {
                cameraFetchInProgress = false
            }
        }
    }

    private fun maybeRefreshRoadCameras(location: Location) {
        if (roadCameras.isEmpty() && lastCameraFetchAt == 0L) {
            loadNearbyCameras(force = false)
            return
        }
        val previous = lastCameraFetchLocation
        if (previous == null) {
            loadNearbyCameras(force = true)
            return
        }
        val elapsed = android.os.SystemClock.elapsedRealtime() - lastCameraFetchAt
        if (elapsed >= CAMERA_REFRESH_INTERVAL_MS || previous.distanceTo(location) >= CAMERA_REFRESH_DISTANCE_METERS) {
            loadNearbyCameras(force = true)
        }
    }

    /** Warns once per mapped enforcement camera during the current guidance session. */
    private fun checkRoadCameraWarnings(location: Location) {
        if (!guidanceActive || location.accuracy > 80f) return
        roadCameras.forEach { camera ->
            if (camera.kind == RoadCameraKind.SURVEILLANCE) return@forEach
            val target = Location("road-camera").apply {
                latitude = camera.latitude
                longitude = camera.longitude
            }
            val distance = location.distanceTo(target)
            if (distance > CAMERA_REARM_DISTANCE_METERS) alertedCameraIds.remove(camera.id)
            val cameraBearing = camera.directionDegrees
            val bearingMatches = cameraBearing == null || !location.hasBearing() || location.speed < 2f || angularDifference(location.bearing.toDouble(), cameraBearing) <= CAMERA_DIRECTION_TOLERANCE_DEGREES
            if (distance <= CAMERA_WARNING_DISTANCE_METERS && bearingMatches && alertedCameraIds.add(camera.id)) {
                val phrase = when (camera.kind) {
                    RoadCameraKind.SPEED -> "Впереди камера контроля скорости"
                    RoadCameraKind.TRAFFIC_ENFORCEMENT -> "Впереди камера контроля перекрёстка"
                    RoadCameraKind.SURVEILLANCE -> return@forEach
                }
                voice.speak(phrase, TextToSpeech.QUEUE_ADD, null, "road-camera-${camera.id}")
                status.text = "$phrase. Данные OpenStreetMap, точность не гарантируется."
            }
        }
    }

    private fun angularDifference(a: Double, b: Double): Double {
        val diff = kotlin.math.abs(((a - b + 540.0) % 360.0) - 180.0)
        return diff
    }

    private fun drawRoadCameras(cameras: List<RoadCamera>) {
        if (!mapReady) return
        mapView.getMapAsync { map ->
            map.style?.let { style ->
                val groups = listOf(
                    Triple(RoadCameraKind.SPEED, CAMERA_SPEED_SOURCE, CAMERA_SPEED_LAYER),
                    Triple(RoadCameraKind.TRAFFIC_ENFORCEMENT, CAMERA_TRAFFIC_SOURCE, CAMERA_TRAFFIC_LAYER),
                    Triple(RoadCameraKind.SURVEILLANCE, CAMERA_SURVEILLANCE_SOURCE, CAMERA_SURVEILLANCE_LAYER)
                )
                groups.forEach { (kind, sourceId, layerId) ->
                    val features = cameras.filter { it.kind == kind }.map { camera ->
                        Feature.fromGeometry(Point.fromLngLat(camera.longitude, camera.latitude)).apply {
                            addStringProperty("description", camera.description)
                        }
                    }
                    val collection = FeatureCollection.fromFeatures(features)
                    val source = style.getSourceAs<GeoJsonSource>(sourceId)
                    if (source != null) source.setGeoJson(collection) else {
                        style.addSource(GeoJsonSource(sourceId, collection))
                        val color = when (kind) {
                            RoadCameraKind.SPEED -> "#E53935"
                            RoadCameraKind.TRAFFIC_ENFORCEMENT -> "#FB8C00"
                            RoadCameraKind.SURVEILLANCE -> "#7E57C2"
                        }
                        style.addLayer(CircleLayer(layerId, sourceId).withProperties(
                            circleRadius(7.0f), circleColor(color), circleStrokeColor("#FFFFFF"), circleStrokeWidth(2.0f)
                        ))
                    }
                }
            }
        }
    }

    private fun updateGpsMarker(location: Location?) {
        if (!mapReady || location == null) return
        mapView.getMapAsync { map ->
            map.style?.let { style ->
                val point = Feature.fromGeometry(Point.fromLngLat(location.longitude, location.latitude))
                val collection = FeatureCollection.fromFeatures(arrayOf(point))
                val source = style.getSourceAs<GeoJsonSource>(GPS_SOURCE_ID)
                if (source != null) source.setGeoJson(collection) else {
                    style.addSource(GeoJsonSource(GPS_SOURCE_ID, collection))
                    style.addLayer(CircleLayer(GPS_LAYER_ID, GPS_SOURCE_ID).withProperties(
                        circleRadius(8.0f), circleColor("#1565C0"), circleStrokeColor("#FFFFFF"), circleStrokeWidth(2.5f)
                    ))
                }
            }
        }
    }

    /** Shows the currently selected destination independently of the route line. */
    private fun updateDestinationMarker(place: Place?) {
        if (!mapReady) return
        mapView.getMapAsync { map ->
            map.style?.let { style ->
                val features = if (place == null) emptyArray() else arrayOf(
                    Feature.fromGeometry(Point.fromLngLat(place.lon, place.lat)).apply {
                        addStringProperty("name", place.name)
                    }
                )
                val collection = FeatureCollection.fromFeatures(features)
                val source = style.getSourceAs<GeoJsonSource>(DESTINATION_SOURCE_ID)
                if (source != null) source.setGeoJson(collection) else {
                    style.addSource(GeoJsonSource(DESTINATION_SOURCE_ID, collection))
                    style.addLayer(CircleLayer(DESTINATION_LAYER_ID, DESTINATION_SOURCE_ID).withProperties(
                        circleRadius(10.0f), circleColor("#D32F2F"),
                        circleStrokeColor("#FFFFFF"), circleStrokeWidth(3.0f)
                    ))
                }
            }
        }
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 12f; setOnClickListener { action() }
    }

    private fun findDestination() {
        val query = search.text.toString().trim()
        if (query.isBlank()) { status.text = "Введите адрес, например: Новокузнецк, проспект Металлургов, 1"; return }
        status.text = "Ищу адрес в офлайн-каталоге и интернете…"
        scope.launch {
            val local = withContext(Dispatchers.IO) {
                (offlineGazetteer.search(query, 8) + offlinePlaceIndex.search(query, 8))
                    .distinctBy { "${(it.lat * 100000).toInt()}:${(it.lon * 100000).toInt()}" }
            }
            try {
                val online = withContext(Dispatchers.IO) { geocode(query) }
                val results = (online + local).distinctBy {
                    "${(it.lat * 100000).toInt()}:${(it.lon * 100000).toInt()}"
                }.take(10)
                if (results.isEmpty()) { status.text = "Адрес не найден ни в онлайн-источнике, ни в локальном каталоге."; return@launch }
                status.text = "Найдено: ${results.size} • локальный каталог: ${local.size}"
                if (results.size == 1) choosePlace(results[0]) else showPlaceChoices(results)
            } catch (e: Exception) {
                if (local.isEmpty()) status.text = "Интернет недоступен. Установите офлайн-каталог Кузбасса или сохраните адрес заранее."
                else {
                    status.text = "Офлайн-поиск • найдено в каталоге и истории: ${local.size}"
                    if (local.size == 1) choosePlace(local[0]) else showPlaceChoices(local)
                }
            }
        }
    }

    private fun chooseOfflineGazetteer() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/octet-stream"
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_OFFLINE_GAZETTEER)
    }

    @Deprecated("Uses the platform document picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_OFFLINE_GAZETTEER || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        status.text = "Проверяю и устанавливаю офлайн-каталог…"
        scope.launch {
            try {
                val installed = withContext(Dispatchers.IO) {
                    contentResolver.openInputStream(uri)?.use { offlineGazetteer.importDatabase(it) }
                        ?: throw IllegalStateException("Не удалось открыть выбранный файл")
                }
                status.text = "Офлайн-каталог установлен: ${installed.records} объектов. Поиск улиц и адресов доступен без интернета."
            } catch (e: Exception) {
                status.text = "Не удалось установить каталог: ${e.message ?: "неверный файл"}"
            }
        }
    }

    private fun geocode(query: String): List<Place> {
        val q = URLEncoder.encode("$query, Кемеровская область, Россия", "UTF-8")
        val arr = org.json.JSONArray(request("https://nominatim.openstreetmap.org/search?format=jsonv2&limit=5&q=$q"))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i); Place(o.optString("display_name"), o.getDouble("lat"), o.getDouble("lon"))
        }
    }

    private fun showPlaceChoices(places: List<Place>) {
        AlertDialog.Builder(this).setTitle("Выберите адрес")
            .setItems(places.map { it.name.take(100) }.toTypedArray()) { _, which -> choosePlace(places[which]) }
            .setNegativeButton("Отмена", null).show()
    }

    private fun choosePlace(place: Place) {
        destinationRouteJob?.cancel()
        offlinePlaceIndex.remember(place)
        updateDestinationMarker(place)
        if (mapReady) mapView.getMapAsync { map ->
            map.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(LatLng(place.lat, place.lon), 15.0))
        }
        val origin = currentLocation
        if (origin == null) {
            currentRoute = RouteInfo(0.0, 0.0, place)
            pendingRouteGeometry = emptyList()
            clearRouteLine()
            status.text = "Найдено: ${place.name}\nНажмите «Моё место» или разрешите доступ к GPS для расчёта маршрута."
            return
        }
        status.text = "Строю маршрут…"
        pendingRouteGeometry = emptyList()
        clearRouteLine()
        destinationRouteJob = scope.launch {
            try {
                var routeMode = "ОНЛАЙН • OSRM"
                var offlineFailure: String? = null
                val (onlineAlternatives, route) = if (offlineRouter.isInstalled()) {
                    try {
                        val local = offlineRouter.route(origin.latitude, origin.longitude, place.lat, place.lon)
                        routeMode = "ОФЛАЙН • Valhalla"
                        val localRoute = RouteInfo(local.distanceKm, local.durationMinutes, place, local.instructions,
                            local.geometry.map { RoutePoint(it.lat, it.lon) },
                            local.maneuvers.map { RouteManeuver(it.lat, it.lon, it.instruction) })
                        emptyList<RouteInfo>() to localRoute
                    } catch (offlineError: Exception) {
                        // A damaged or incomplete local extract should not block an online route.
                        offlineFailure = offlineError.message
                        val alternatives = withContext(Dispatchers.IO) { buildOnlineRoutes(origin.latitude, origin.longitude, place) }
                        alternatives to alternatives.first()
                    }
                } else {
                    val alternatives = withContext(Dispatchers.IO) { buildOnlineRoutes(origin.latitude, origin.longitude, place) }
                    alternatives to alternatives.first()
                }
                if (onlineAlternatives.size > 1) {
                    val options = onlineAlternatives
                    val labels = options.mapIndexed { index, option ->
                        val suffix = if (index == 0) " • рекомендуемый" else ""
                        "Вариант ${index + 1}$suffix\n${"%.1f".format(option.distanceKm)} км • ${option.durationMin.toInt()} мин."
                    }.toTypedArray()
                    status.text = "Найдено ${options.size} варианта маршрута. Выберите подходящий."
                    AlertDialog.Builder(this@MainActivity).setTitle("Варианты маршрута")
                        .setItems(labels) { _, selected -> activateRoute(options[selected], routeMode, offlineFailure) }
                        .setNegativeButton("Оставить рекомендуемый") { _, _ -> activateRoute(route, routeMode, offlineFailure) }
                        .setOnCancelListener { activateRoute(route, routeMode, offlineFailure) }
                        .show()
                } else activateRoute(route, routeMode, offlineFailure)
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (e: Exception) { status.text = "Адрес найден, но маршрут не построен: ${e.message ?: "нет сети"}" }
        }
    }

    /** Clears the selected destination and any active route/session. */
    private fun clearDestination() {
        destinationRouteJob?.cancel()
        destinationRouteJob = null
        currentRoute = null
        activeRouteMode = "Маршрут"
        pendingRouteGeometry = emptyList()
        RouteSessionStore.save(applicationContext, null)
        guidanceActive = false
        offRouteSamples = 0
        rerouteInProgress = false
        stopLocationService()
        voice.stop()
        clearRouteLine()
        updateDestinationMarker(null)
        status.text = "Пункт назначения и маршрут сброшены. Найдите новый адрес."
    }

    private fun buildRoute(lat: Double, lon: Double, dest: Place): RouteInfo =
        buildOnlineRoutes(lat, lon, dest).first()

    /** Requests OSRM alternatives and converts each returned route into the app model. */
    private fun buildOnlineRoutes(lat: Double, lon: Double, dest: Place): List<RouteInfo> {
        val url = "https://router.project-osrm.org/route/v1/driving/$lon,$lat;${dest.lon},${dest.lat}?overview=full&geometries=geojson&steps=true&alternatives=true"
        val json = JSONObject(request(url))
        val routes = json.getJSONArray("routes")
        if (routes.length() == 0) throw IllegalStateException("маршрут не найден")
        return (0 until routes.length()).map { routeIndex ->
            val routeObject = routes.getJSONObject(routeIndex)
            val coordinates = routeObject.optJSONObject("geometry")?.optJSONArray("coordinates")
            val geometry = if (coordinates == null) emptyList() else (0 until coordinates.length()).map { i ->
                val pair = coordinates.getJSONArray(i)
                RoutePoint(pair.getDouble(1), pair.getDouble(0))
            }
            val maneuvers = mutableListOf<RouteManeuver>()
            val legs = routeObject.optJSONArray("legs")
            if (legs != null) for (legIndex in 0 until legs.length()) {
                val steps = legs.getJSONObject(legIndex).optJSONArray("steps") ?: continue
                for (stepIndex in 0 until steps.length()) {
                    val step = steps.getJSONObject(stepIndex)
                    val maneuver = step.optJSONObject("maneuver") ?: continue
                    val location = maneuver.optJSONArray("location") ?: continue
                    if (location.length() < 2) continue
                    val instruction = osrmInstruction(maneuver.optString("type"), maneuver.optString("modifier"), step.optString("name"))
                    if (instruction.isNotBlank()) maneuvers += RouteManeuver(location.getDouble(1), location.getDouble(0), instruction)
                }
            }
            RouteInfo(routeObject.getDouble("distance") / 1000.0, routeObject.getDouble("duration") / 60.0, dest,
                instructions = maneuvers.map { it.instruction }, geometry = geometry, maneuvers = maneuvers)
        }
    }

    /** Saves and displays the route chosen by the user (or the router's only result). */
    private fun activateRoute(route: RouteInfo, routeMode: String, offlineFailure: String?) {
        currentRoute = route
        activeRouteMode = routeMode
        RouteSessionStore.save(applicationContext, route)
        if (guidanceActive) startService(Intent(this, NavigationLocationService::class.java).setAction(NavigationLocationService.ACTION_ROUTE_UPDATED))
        nextManeuverIndex = 0
        announcedManeuverStages.clear()
        lastManeuverDistanceMeters = null
        hasAnnouncedArrival = false
        pendingRouteGeometry = route.geometry
        drawRoute(route.geometry)
        val nextSteps = route.instructions.take(3).joinToString("\n")
        status.text = "До ${route.destination.name}\n${"%.1f".format(route.distanceKm)} км • около ${route.durationMin.toInt()} мин.\n$routeMode" +
            (offlineFailure?.let { "\nОфлайн-маршрут недоступен: $it" } ?: "") +
            if (nextSteps.isNotBlank()) "\n\nПервые манёвры:\n$nextSteps" else ""
        val firstStep = route.instructions.firstOrNull()?.let { " Далее: $it" }.orEmpty()
        voice.speak("Маршрут построен. Расстояние ${route.distanceKm.toInt()} километров. В пути примерно ${route.durationMin.toInt()} минут.$firstStep", TextToSpeech.QUEUE_FLUSH, null, "route")
    }

    private fun osrmInstruction(type: String, modifier: String, roadName: String): String {
        val direction = when (modifier.lowercase(Locale.ROOT)) {
            "uturn", "uturn left", "uturn right" -> "развернитесь"
            "sharp left" -> "резко поверните налево"
            "left" -> "поверните налево"
            "slight left" -> "плавно поверните налево"
            "sharp right" -> "резко поверните направо"
            "right" -> "поверните направо"
            "slight right" -> "плавно поверните направо"
            "straight" -> "продолжайте прямо"
            "exit" -> "съезжайте"
            "(unknown)" -> "продолжайте движение"
            else -> when (type.lowercase(Locale.ROOT)) {
                "depart" -> "начните движение"
                "arrive" -> "прибытие в пункт назначения"
                "roundabout", "rotary" -> "на круговом движении следуйте указателям"
                "merge" -> "перестройтесь"
                "on ramp" -> "выезжайте на съезд"
                else -> "продолжайте движение"
            }
        }
        val road = roadName.trim()
        return if (road.isNotEmpty()) "$direction на $road" else direction
    }

    /** Distance-based voice prompts for the next OSRM/Valhalla maneuver. */
    private fun announceNextManeuver(location: Location, route: RouteInfo) {
        if (!guidanceActive || route.maneuvers.isEmpty()) return
        while (nextManeuverIndex < route.maneuvers.size) {
            val maneuver = route.maneuvers[nextManeuverIndex]
            val target = Location("maneuver").apply { latitude = maneuver.lat; longitude = maneuver.lon }
            val meters = location.distanceTo(target)
            val index = nextManeuverIndex
            val instruction = maneuver.instruction.trim().removeSuffix(".")
            // Emit only the closest applicable prompt on this GPS sample to avoid
            // queuing three duplicate instructions when guidance starts near a turn.
            when {
                meters <= 50f && "$index:50" !in announcedManeuverStages -> {
                    announcedManeuverStages += "$index:50"
                    voice.speak(instruction, TextToSpeech.QUEUE_ADD, null, "maneuver-$index-now")
                }
                meters <= 200f && "$index:200" !in announcedManeuverStages -> {
                    announcedManeuverStages += "$index:200"
                    voice.speak("Через двести метров: $instruction", TextToSpeech.QUEUE_ADD, null, "maneuver-$index-200")
                }
                meters <= 700f && "$index:700" !in announcedManeuverStages -> {
                    announcedManeuverStages += "$index:700"
                    voice.speak("Через семьсот метров: $instruction", TextToSpeech.QUEUE_ADD, null, "maneuver-$index-700")
                }
            }
            val previousDistance = lastManeuverDistanceMeters
            val passedManeuver = meters <= 25f || (previousDistance != null && previousDistance < 45f && meters > previousDistance + 8f)
            lastManeuverDistanceMeters = meters
            if (passedManeuver) {
                nextManeuverIndex++
                lastManeuverDistanceMeters = null
                continue
            }
            break
        }
    }

    /** Draws the active route as a GeoJSON line on the current MapLibre style. */
    private fun drawRoute(points: List<RoutePoint>) {
        if (!mapReady || points.size < 2) return
        mapView.getMapAsync { map ->
            map.style?.let { style ->
                val feature = Feature.fromGeometry(LineString.fromLngLats(points.map { Point.fromLngLat(it.lon, it.lat) }))
                val collection = FeatureCollection.fromFeatures(arrayOf(feature))
                val source = style.getSourceAs<GeoJsonSource>(ROUTE_SOURCE_ID)
                if (source != null) {
                    source.setGeoJson(collection)
                } else {
                    style.addSource(GeoJsonSource(ROUTE_SOURCE_ID, collection))
                    style.addLayer(LineLayer(ROUTE_LAYER_ID, ROUTE_SOURCE_ID).withProperties(
                        lineColor("#1976D2"), lineWidth(5.0f), lineCap("round"), lineJoin("round")
                    ))
                }
                val bounds = LatLngBounds.Builder().apply {
                    points.forEach { include(LatLng(it.lat, it.lon)) }
                }.build()
                map.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngBounds(bounds, 56))
            }
        }
    }

    private fun clearRouteLine() {
        if (!mapReady) return
        mapView.getMapAsync { map ->
            map.style?.getSourceAs<GeoJsonSource>(ROUTE_SOURCE_ID)
                ?.setGeoJson(FeatureCollection.fromFeatures(emptyArray()))
        }
    }

    private fun request(url: String): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 12000; conn.readTimeout = 18000
        conn.setRequestProperty("User-Agent", "MyNavigationAndroid/0.2 (personal navigation app)")
        return try { conn.inputStream.bufferedReader().use { it.readText() } } finally { conn.disconnect() }
    }

    private fun requestLocation() {
        val fineGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted && !coarseGranted) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 41); return
        }
        val manager = getSystemService(LOCATION_SERVICE) as LocationManager
        currentLocation = try {
            manager.getProviders(true).mapNotNull { provider ->
                try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
            }.maxByOrNull { it.time }
        } catch (_: Exception) { null }
        if (currentLocation != null) status.text = "GPS: местоположение получено. Можно искать адрес."
    }

    private fun locateMe() {
        requestLocation(); val loc = currentLocation
        if (loc == null) { status.text = "Пока нет координат GPS. Включите геолокацию и разрешите доступ."; return }
        mapView.getMapAsync { map -> map.animateCamera(org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(LatLng(loc.latitude, loc.longitude), 15.0)) }
        status.text = "Ваше местоположение: %.5f, %.5f".format(loc.latitude, loc.longitude)
    }

    private fun saveCurrentDestination() {
        val place = currentRoute?.destination
        if (place == null) { status.text = "Сначала найдите адрес."; return }
        val old = prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
        old.add("${place.name}|${place.lat}|${place.lon}")
        prefs.edit().putStringSet("favorites", old).apply()
        offlinePlaceIndex.remember(place)
        status.text = "Адрес сохранён в избранном и локальном поиске."
    }

    private fun showFavorites() {
        val items = prefs.getStringSet("favorites", emptySet())?.toList().orEmpty()
        if (items.isEmpty()) { status.text = "Избранных адресов пока нет."; return }
        AlertDialog.Builder(this).setTitle("Избранные адреса")
            .setItems(items.map { it.substringBefore("|").take(90) }.toTypedArray()) { _, which ->
                val p = items[which].split("|"); choosePlace(Place(p[0], p[1].toDouble(), p[2].toDouble()))
            }.setNegativeButton("Закрыть", null).show()
    }

    override fun onInit(statusCode: Int) { if (statusCode == TextToSpeech.SUCCESS) voice.language = Locale("ru", "RU") }

    companion object {
        private const val REQUEST_OFFLINE_GAZETTEER = 7301
        @Volatile var activityVisible: Boolean = false
            private set
        const val ROUTE_SOURCE_ID = "active-route-source"
        const val ROUTE_LAYER_ID = "active-route-line"
        const val GPS_SOURCE_ID = "current-gps-position-source"
        const val GPS_LAYER_ID = "current-gps-position-circle"
        const val DESTINATION_SOURCE_ID = "selected-destination-source"
        const val DESTINATION_LAYER_ID = "selected-destination-circle"
        const val OFF_ROUTE_THRESHOLD_METERS = 65.0
        const val OFF_ROUTE_REQUIRED_SAMPLES = 3
        const val REROUTE_COOLDOWN_MS = 15_000L
        const val REROUTE_MAX_ACCURACY_METERS = 35f
        const val REROUTE_MAX_FIX_AGE_MS = 15_000L
        const val REROUTE_DESTINATION_GUARD_METERS = 100f
        const val CAMERA_REFRESH_INTERVAL_MS = 30 * 60 * 1000L
        const val CAMERA_REFRESH_DISTANCE_METERS = 10_000f
        const val CAMERA_WARNING_DISTANCE_METERS = 600f
        const val CAMERA_REARM_DISTANCE_METERS = 1_200f
        const val CAMERA_DIRECTION_TOLERANCE_DEGREES = 70.0
        const val CAMERA_SPEED_SOURCE = "road-camera-speed-source"
        const val CAMERA_SPEED_LAYER = "road-camera-speed-layer"
        const val CAMERA_TRAFFIC_SOURCE = "road-camera-traffic-source"
        const val CAMERA_TRAFFIC_LAYER = "road-camera-traffic-layer"
        const val CAMERA_SURVEILLANCE_SOURCE = "road-camera-surveillance-source"
        const val CAMERA_SURVEILLANCE_LAYER = "road-camera-surveillance-layer"
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            requestLocation()
            status.text = "Разрешение получено. Нажмите «Начать слежение» для запуска фоновой навигации."
        }
    }
    override fun onStart() {
        super.onStart()
        activityVisible = true
        RouteSessionStore.load(this)?.let { savedRoute ->
            currentRoute = savedRoute
            activeRouteMode = "Сохранённый маршрут"
            if (savedRoute.geometry.isNotEmpty()) {
                pendingRouteGeometry = savedRoute.geometry
                if (mapReady) drawRoute(savedRoute.geometry)
            }
        }
        val savedProgress = RouteSessionStore.loadProgress(this)
        nextManeuverIndex = maxOf(nextManeuverIndex, savedProgress.maneuverIndex)
        announcedManeuverStages.addAll(savedProgress.maneuverStages)
        alertedCameraIds.addAll(savedProgress.alertedCameraIds)
        mapView.onStart()
        registerLocationReceiver()
    }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { activityVisible = false; unregisterLocationReceiver(); mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
    override fun onDestroy() { scope.cancel(); offlineRouter.close(); voice.stop(); voice.shutdown(); mapView.onDestroy(); super.onDestroy() }
}
