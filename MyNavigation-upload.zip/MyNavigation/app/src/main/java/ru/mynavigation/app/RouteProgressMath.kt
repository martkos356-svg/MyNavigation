package ru.mynavigation.app

/** Small, platform-independent estimates used by the navigation status panel. */
object RouteProgressMath {
    /** Scales the original route duration by remaining distance; returns null for invalid input. */
    fun estimateRemainingMinutes(
        totalDistanceKm: Double,
        totalDurationMin: Double,
        remainingDistanceKm: Double
    ): Int? {
        if (!totalDistanceKm.isFinite() || !totalDurationMin.isFinite() ||
            !remainingDistanceKm.isFinite() || totalDistanceKm <= 0.0 ||
            totalDurationMin < 0.0 || remainingDistanceKm < 0.0) return null
        val ratio = (remainingDistanceKm / totalDistanceKm).coerceIn(0.0, 1.0)
        return (totalDurationMin * ratio).toInt()
    }
}
