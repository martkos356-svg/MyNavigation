package ru.mynavigation.app.routing

import android.content.Context
import org.json.JSONObject
import com.valhalla.valhalla.Valhalla
import com.valhalla.valhalla.config.ValhallaConfigFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.io.IOException

/** On-device routing against the installed Valhalla tile extract. */
class OfflineValhallaRouter(context: Context) : Closeable {
    private val appContext = context.applicationContext
    private val tileFile = File(
        appContext.getExternalFilesDir(null) ?: appContext.filesDir,
        "valhalla/valhalla_tiles.tar"
    )
    @Volatile private var engine: Valhalla? = null

    data class RoutePoint(val lat: Double, val lon: Double)

    data class Maneuver(val lat: Double, val lon: Double, val instruction: String)

    data class Result(
        val distanceKm: Double,
        val durationMinutes: Double,
        val instructions: List<String>,
        val geometry: List<RoutePoint>,
        val maneuvers: List<Maneuver>
    )

    fun isInstalled(): Boolean = tileFile.isFile && tileFile.length() > 0L

    private fun engine(): Valhalla {
        engine?.let { return it }
        synchronized(this) {
            engine?.let { return it }
            if (!isInstalled()) throw IOException("Офлайн-дорожная база не установлена")
            val config = ValhallaConfigFactory.usingTileExtract(tileFile.absolutePath)
            return Valhalla(appContext, config).also { engine = it }
        }
    }

    suspend fun route(fromLat: Double, fromLon: Double, toLat: Double, toLon: Double): Result =
        withContext(Dispatchers.IO) {
            requireCoordinate(fromLat, fromLon)
            requireCoordinate(toLat, toLon)
            val request = JSONObject().apply {
                put("locations", org.json.JSONArray().apply {
                    put(JSONObject().put("lat", fromLat).put("lon", fromLon).put("type", "break"))
                    put(JSONObject().put("lat", toLat).put("lon", toLon).put("type", "break"))
                })
                put("costing", "auto")
                put("directions_options", JSONObject().apply {
                    put("units", "kilometers")
                    put("language", "ru-RU")
                })
            }
            val responseText = engine().routeRaw(request.toString())
            val root = JSONObject(responseText)
            val trip = root.optJSONObject("trip")
                ?: throw IOException(root.optJSONObject("error")?.optString("message") ?: "Valhalla не вернула маршрут")
            val legs = trip.optJSONArray("legs") ?: throw IOException("В ответе Valhalla нет участков маршрута")
            if (legs.length() == 0) throw IOException("Маршрут не содержит участков")
            var distance = 0.0
            var seconds = 0.0
            val steps = mutableListOf<String>()
            val maneuversOut = mutableListOf<Maneuver>()
            val geometry = mutableListOf<RoutePoint>()
            for (i in 0 until legs.length()) {
                val leg = legs.getJSONObject(i)
                val summary = leg.optJSONObject("summary")
                if (summary != null) {
                    distance += summary.optDouble("length", 0.0)
                    seconds += summary.optDouble("time", 0.0)
                }
                val encodedShape = leg.optString("shape", "")
                if (encodedShape.isNotBlank()) geometry += decodePolyline6(encodedShape)
                val maneuvers = leg.optJSONArray("maneuvers")
                if (maneuvers != null) for (j in 0 until maneuvers.length()) {
                    val maneuver = maneuvers.getJSONObject(j)
                    val instruction = maneuver.optString("instruction").trim()
                    if (instruction.isNotEmpty()) {
                        steps += instruction
                        val shapeIndex = maneuver.optInt("begin_shape_index", -1)
                        if (shapeIndex in geometry.indices) {
                            val point = geometry[shapeIndex]
                            maneuversOut += Maneuver(point.lat, point.lon, instruction)
                        }
                    }
                }
            }
            if (distance <= 0.0 || seconds <= 0.0) throw IOException("Valhalla вернула маршрут без корректной длины или времени")
            if (geometry.isEmpty()) throw IOException("В ответе Valhalla отсутствует геометрия маршрута")
            Result(distance, seconds / 60.0, steps, geometry, maneuversOut)
        }

    /** Decodes Valhalla's encoded polyline with precision 6. */
    private fun decodePolyline6(encoded: String): List<RoutePoint> {
        val points = ArrayList<RoutePoint>()
        var index = 0
        var lat = 0
        var lon = 0
        while (index < encoded.length) {
            var result = 0
            var shift = 0
            var byte: Int
            do {
                if (index >= encoded.length || shift > 30) throw IOException("Повреждена геометрия маршрута")
                byte = encoded[index++].code - 63
                if (byte < 0 || byte > 63) throw IOException("Повреждена геометрия маршрута")
                result = result or ((byte and 0x1f) shl shift)
                shift += 5
            } while (byte >= 0x20)
            val deltaLat = if ((result and 1) != 0) (result shr 1).inv() else result shr 1
            lat += deltaLat

            result = 0
            shift = 0
            do {
                if (index >= encoded.length || shift > 30) throw IOException("Повреждена геометрия маршрута")
                byte = encoded[index++].code - 63
                if (byte < 0 || byte > 63) throw IOException("Повреждена геометрия маршрута")
                result = result or ((byte and 0x1f) shl shift)
                shift += 5
            } while (byte >= 0x20)
            val deltaLon = if ((result and 1) != 0) (result shr 1).inv() else result shr 1
            lon += deltaLon
            points += RoutePoint(lat / 1_000_000.0, lon / 1_000_000.0)
        }
        return points
    }

    private fun requireCoordinate(lat: Double, lon: Double) {
        require(lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0) {
            "Некорректные координаты"
        }
    }

    @Synchronized override fun close() {
        engine?.close()
        engine = null
    }
}
