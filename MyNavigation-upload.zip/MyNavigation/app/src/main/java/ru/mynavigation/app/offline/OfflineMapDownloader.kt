package ru.mynavigation.app.offline

import android.content.Context
import org.json.JSONObject
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition

/** Управляет офлайн-регионами MapLibre. Само построение дорог/маршрутов здесь не выполняется. */
class OfflineMapDownloader(context: Context) {
    private val manager = OfflineManager.getInstance(context.applicationContext)

    fun isProviderConfigured(): Boolean = OfflineMapConfig.STYLE_URL.startsWith("https://")

    fun download(
        preset: OfflineMapConfig.RegionPreset,
        onProgress: (String) -> Unit,
        reportError: (String) -> Unit
    ) {
        if (!isProviderConfigured()) {
            reportError("Не задан URL картографического стиля. Добавьте в OfflineMapConfig.STYLE_URL HTTPS-адрес провайдера, который разрешает офлайн-загрузку.")
            return
        }
        val bounds = LatLngBounds.from(preset.north, preset.east, preset.south, preset.west)
        val definition = OfflineTilePyramidRegionDefinition(
            OfflineMapConfig.STYLE_URL,
            bounds,
            preset.minZoom,
            preset.maxZoom,
            1.0f
        )
        val metadata = JSONObject().put("id", preset.id).put("title", preset.title).toString().toByteArray()
        manager.createOfflineRegion(definition, metadata, object : OfflineManager.CreateOfflineRegionCallback {
            override fun onCreate(region: OfflineRegion) {
                region.setObserver(object : OfflineRegion.OfflineRegionObserver {
                    override fun onError(error: org.maplibre.android.offline.OfflineRegionError) {
                        reportError(error.message ?: "Ошибка загрузки офлайн-карты")
                    }

                    override fun mapboxTileCountLimitExceeded(limit: Long) {
                        reportError("Достигнут лимит тайлов: $limit. Уменьшите диапазон масштаба или разделите регион.")
                    }

                    override fun onStatusChanged(status: OfflineRegionStatus) {
                        val total = status.requiredResourceCount
                        val done = status.completedResourceCount
                        val percent = if (total > 0) (done * 100 / total).coerceIn(0, 100) else 0
                        val sizeMb = status.completedResourceSize / (1024.0 * 1024.0)
                        onProgress("${preset.title}: $percent% ($done/$total ресурсов), ${"%.1f".format(sizeMb)} МБ")
                        if (status.isComplete) onProgress("${preset.title}: карта загружена и сохранена на устройстве")
                    }
                })
                region.setDownloadState(OfflineRegion.STATE_ACTIVE)
                onProgress("Загрузка началась: ${preset.title}")
            }

            override fun onError(error: String) = reportError(error)
        })
    }

    fun listSaved(onResult: (List<String>) -> Unit, reportError: (String) -> Unit) {
        manager.listOfflineRegions(object : OfflineManager.ListOfflineRegionsCallback {
            override fun onList(offlineRegions: Array<OfflineRegion>?) {
                val rows = offlineRegions.orEmpty().map { region ->
                    val title = try { JSONObject(String(region.metadata)).optString("title", "Регион ${region.id}") }
                    catch (_: Exception) { "Регион ${region.id}" }
                    "$title (ID ${region.id})"
                }
                onResult(rows)
            }

            override fun onError(error: String) = reportError(error)
        })
    }
}
