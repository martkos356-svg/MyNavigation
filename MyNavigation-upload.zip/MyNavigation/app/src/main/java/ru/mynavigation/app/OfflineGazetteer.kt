package ru.mynavigation.app

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.io.File
import java.text.Normalizer
import java.util.Locale

/** Searchable regional OSM catalogue imported by the user as a SQLite file. */
class OfflineGazetteer(context: Context) {
    private val databaseFile = File(context.applicationContext.filesDir, DATABASE_NAME)

    data class Status(val installed: Boolean, val records: Long)

    fun status(): Status {
        if (!databaseFile.isFile || databaseFile.length() == 0L) return Status(false, 0)
        return runCatching {
            val db = SQLiteDatabase.openDatabase(databaseFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            db.use {
                val count = it.rawQuery("SELECT value FROM metadata WHERE key='record_count'", null).use { c ->
                    if (c.moveToFirst()) c.getString(0).toLongOrNull() ?: 0L else 0L
                }
                Status(count > 0, count)
            }
        }.getOrDefault(Status(false, 0))
    }

    /** Copies and validates a generated catalogue before atomically replacing the current one. */
    @Synchronized
    fun importDatabase(source: java.io.InputStream): Status {
        val temp = File(databaseFile.parentFile, "$DATABASE_NAME.part")
        try {
            source.buffered().use { input ->
                temp.outputStream().buffered().use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var total = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        require(total <= MAX_DATABASE_BYTES) { "Файл каталога превышает допустимый размер 1 ГБ" }
                        output.write(buffer, 0, read)
                    }
                }
            }
            val db = SQLiteDatabase.openDatabase(temp.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            val count = db.use {
                val integrity = it.rawQuery("PRAGMA integrity_check", null).use { c ->
                    c.moveToFirst() && c.getString(0).equals("ok", ignoreCase = true)
                }
                require(integrity) { "SQLite-файл повреждён: проверка целостности не пройдена" }
                val tables = it.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null).use { c ->
                    buildSet { while (c.moveToNext()) add(c.getString(0)) }
                }
                require("places" in tables && "metadata" in tables) { "Файл не является каталогом MyNavigation" }
                val columns = it.rawQuery("PRAGMA table_info(places)", null).use { c ->
                    buildSet { while (c.moveToNext()) add(c.getString(1)) }
                }
                require(setOf("id", "name", "search_text", "lat", "lon", "kind").all { it in columns }) {
                    "В каталоге отсутствуют обязательные поля"
                }
                val schemaVersion = it.rawQuery("SELECT value FROM metadata WHERE key='schema_version'", null).use { c ->
                    if (c.moveToFirst()) c.getString(0).toIntOrNull() ?: 0 else 0
                }
                require(schemaVersion in 1..2) { "Неподдерживаемая версия каталога: $schemaVersion" }
                if (schemaVersion >= 2) require("place_tokens" in tables) {
                    "В каталоге версии 2 отсутствует индекс поиска"
                }
                it.rawQuery("SELECT value FROM metadata WHERE key='record_count'", null).use { c ->
                    require(c.moveToFirst()) { "В каталоге отсутствует счётчик записей" }
                    c.getString(0).toLongOrNull() ?: 0L
                }.also { declared ->
                    val actual = it.rawQuery("SELECT COUNT(*) FROM places", null).use { c -> c.moveToFirst(); c.getLong(0) }
                    require(declared == actual) { "Счётчик записей не совпадает с содержимым каталога" }
                }
            }
            require(count >= 100) { "В каталоге слишком мало объектов" }
            val backup = File(databaseFile.parentFile, "$DATABASE_NAME.backup")
            backup.delete()
            val hadPrevious = databaseFile.exists()
            if (hadPrevious && !databaseFile.renameTo(backup)) {
                throw IllegalStateException("Не удалось сохранить предыдущий каталог")
            }
            if (!temp.renameTo(databaseFile)) {
                if (hadPrevious) backup.renameTo(databaseFile)
                throw IllegalStateException("Не удалось установить новый каталог")
            }
            backup.delete()
            return Status(true, count)
        } catch (error: Throwable) {
            temp.delete()
            throw error
        }
    }

    fun search(query: String, limit: Int = 8): List<Place> {
        val tokens = normalize(query).split(' ').filter { it.length >= 2 }.distinct().take(6)
        if (tokens.isEmpty() || !databaseFile.isFile) return emptyList()
        return runCatching {
            val db = SQLiteDatabase.openDatabase(databaseFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            db.use {
                val hasTokenIndex = it.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='place_tokens'", null).use { c -> c.moveToFirst() }
                val sql: String
                val args: Array<String>
                if (hasTokenIndex) {
                    val clauses = tokens.joinToString(" AND ") { "EXISTS (SELECT 1 FROM place_tokens t WHERE t.place_id=p.id AND t.token GLOB ?)" }
                    sql = "SELECT p.name, p.lat, p.lon FROM places p WHERE $clauses ORDER BY p.name LIMIT ?"
                    args = (tokens.map { "${it}*" } + limit.coerceIn(1, 20).toString()).toTypedArray()
                } else {
                    // Backward-compatible search for schema v1 catalogues.
                    val clauses = tokens.joinToString(" AND ") { "search_text LIKE ? ESCAPE '\\'" }
                    sql = "SELECT name, lat, lon FROM places WHERE $clauses ORDER BY name LIMIT ?"
                    args = (tokens.map { "%${escapeLike(it)}%" } + limit.coerceIn(1, 20).toString()).toTypedArray()
                }
                it.rawQuery(sql, args).use { cursor ->
                    buildList {
                        while (cursor.moveToNext()) {
                            val name = cursor.getString(0)
                            val lat = cursor.getDouble(1)
                            val lon = cursor.getDouble(2)
                            if (name.isNotBlank() && lat.isFinite() && lon.isFinite() && lat in -90.0..90.0 && lon in -180.0..180.0) {
                                add(Place(name, lat, lon))
                            }
                        }
                    }
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun escapeLike(value: String): String = value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    private fun normalize(value: String): String = Normalizer.normalize(value, Normalizer.Form.NFD)
        .replace("\\p{Mn}+".toRegex(), "").lowercase(Locale.ROOT).replace('ё', 'е')
        .replace("[^\\p{L}\\p{N}]+".toRegex(), " ").trim()

    companion object {
        const val DATABASE_NAME = "kuzbass_places.sqlite"
        private const val MAX_DATABASE_BYTES = 1L * 1024 * 1024 * 1024
    }
}
